#from read_json_file import *
import json
import serial
from read_from_xr75 import read_again_xr75

def check_in_list(find_number):
#def check_in_list( ):
    #find_number=817
    flag=0
    paramater_list={823:"Alarm Option",
                    824:"High Temp Alarm Threshold",
                    825:"Low Temp Alarm Threshold",
                    826:"Alarm Hysteresis",
                    827:"Alarm Delay",
                    828:"Startup Alarm Delay",
                    520:"Discharge Air Sensor Failure",
                    521:"Defrost Temp Sensor Failure",
                    522:"Sensor 3 Failure",
                    523:"Condensing Unit Sensor Failure(Sensor 4 Failure)",
                    524:"High Temp Alarm",
                    525:"Low Temp Alarm",
                    528:"External Alarm",
                    529:"Pressure Switches Trip(Severe Alarm Status)",
                    530:"Door Open Status",
                    817:"Auxiliary Relay Action",
                    818:"Auxiliary Relay Setpoint",
                    819:"Auxiliary Relay Differential",
                    820:"Auxiliary Relay Probe Selection",
                    821:"Auxiliary Relay Switched Off During Defrost",
                    795:"Defrost Mode",
                    798:"Defrost Termination Setpoint",
                    800:"Defrost Interval",
                    801:"Max Defrost Duration",
                    803:"Defrost Delay",
                    806:"Drip Time",
                    808:"Defrost Delay After Fast Freezing",
                    809:"Fan Mode",
                    810:"Fan Delay after defrost",
                    811:"Fan Temp Hystersis",
                    812:"Fan Stop Temp Setpoint",
                    813:"Fan Ontime",
                    814:"Fan Offtime",
                    850:"Compressor Fan Status When Door Open",
                    875:"Probe Sensor Type",
                    264:"Discharge Air Temp",
                    265:"Defrost Temp Read",
                    266:"Probe 3 Value",
                    267:"Probe 4 Value",
                    519:"DI1 Status",
                    548:"DI2 Status",
                    536:"Defrost Status",
                    537:"Alarm Status",
                    538:"Light Status",
                    539:"Fan Status",
                    540:"Aux Relay Status",
                    542:"Compressor Status",
                    544:"Buzzer Status",
                    512:"Device Override",
                    513:"Defrost Override",
                    514:"Pulldown Override",
                    515:"Keyboard LOCK/UN-LOCK Status",
                    516:"Mute Alarm Override",
                    538:"Light Override",
                    540:"Auxillary Relay Override",
                    769:"Differential For Cut IN",
                    770:"Minimum Setpoint Limit",
                    771:"Maximum Setpoint Limit",
                    779:"Compressor Startup Delay",
                    780:"Minimum Compressor Off Time",
                    783:"Pulldown Duration",
                    784:"Pulldown Setpoint",
                    785:"Failsafe Compressor ON Time",
                    786:"Failsafe Compressor OFF Time",
                    788:"Temp Measurement Unit",
                    882:"Active Setpoint",
                    886:"Control Setpoint",
                    874:"Modbus Slave Address",
                    876:"Controller Enable",
                    534:"Control Status",
                    541:"Neutral Zone Status",
                    551:"Energy Saving Status",        
        }    
    for reg_num,reg_name in paramater_list.items():
        if( find_number ==reg_num):
#             print(reg_name)
            flag=1
            #response_list=[1]
            #response_list.append(reg_name)
            #return response_list
    if(flag==0):
        print(" ")
#         print("This is hand shaking modbus frame")

    return flag


def find_parameter_name(find_number,count,data):
    paramater_list={823:"Alarm_Option",
                    824:"High_Temp_Alarm_Threshold",
                    825:"Low_Temp_Alarm_Threshold",
                    826:"Alarm_Hysteresis",
                    827:"Alarm_Delay",
                    828:"Startup_Alarm_Delay",
                    520:"Dischargr_Air_Sensor_Failure",
                    521:"defrost_temp_sensor_failure",
                    522:"Sensor_3_Failure",
                    523:"Condensing_Unit_Sensor_Failure",
                    524:"High_Temp_Alarm",
                    525:"Low_Temp_Alarm",
                    528:"External_Alarm",
                    529:"Pressure_Switches_Trip(Severe_Alarm_Status)",
                    530:"Door_Open_Status",
                    817:"Auxiliary_Relay_Action",
                    818:"Auxiliary_Relay_Setpoint",
                    819:"Auxiliary_Relay_Differential",
                    820:"Auxiliary_Relay_Probe_Selection",
                    821:"Auxiliary_Relay_Switched_Off_During_Defrost",
                    795:"Defrost_Mode",
                    798:"Defrost_Termination_Setpoint",
                    800:"Defrost_Interval",
                    801:"Max_Defrost_Duration",
                    803:"Defrost_Delay",
                    806:"Drip_Time",
                    808:"Defrost_Delay_After_Fast_Freezing",
                    809:"Fan_Mode",
                    810:"Fan_Delay_after_defrost",
                    811:"Fan_Temp_Hystersis",
                    812:"Fan_StopTemp_Setpoint",
                    813:"Fan_Ontime",
                    814:"Fan_Offtime",
                    850:"Compressor_Fan_Status_When_Door_Open",
                    875:"Probe_Sensor_Type",
                    264:"Discharge_Air_Temp",
                    265:"Defrost_Temp_Read",
                    266:"Probe_3_Value",
                    267:"Probe_4_Value",
                    519:"DI1_Status",
                    548:"DI2_Status",
                    536:"Defrost_Status",
                    537:"Alarm_Status",
                    538:"Light_Status",
                    539:"Fan_Status",
                    540:"Aux_Relay_Status",
                    542:"Compressor_Status",
                    544:"Buzzer_Status",
                    512:"Device_Override",
                    513:"Defrost_Override",
                    514:"Pulldown_Override",
                    515:"Keyboard_LOCK/UN_LOCK_Status",
                    516:"Mute_Alarm_Override",
                    538:"Light_Override",
                    540:"Auxillary_Relay_Override",
                    769:"Differential_For_Cut_IN",
                    770:"Minimum_Setpoint_Limit",
                    771:"Maximum_Setpoint_Limit",
                    779:"Compressor_Startup_Delay",
                    780:"Minimum_Compressor_Off_Time",
                    783:"Pulldown_Duration",
                    784:"Pulldown_Setpoint",
                    785:"Failsafe_Compressor_ON_Time",
                    786:"Failsafe_Compressor_OFF_Time",
                    788:"Temp_Measurement_Unit",
                    882:"Active_Setpoint",
                    886:"Control_Setpoint",
                    874:"Modbus_Slave_Address",
                    876:"Controller_Enable",
                    534:"Control_Status",
                    541:"Neutral_Zone_Status",
                    551:"Energy_Saving_Status",        
        }
    
    return_list=list(range(0,0))
#     print("return_list",return_list)
    parameter_find_list=list(range(find_number,find_number+data[5]))
#     print(parameter_find_list)
    
    i=0
    if(data[1]==1 or data[1]==2):
        #:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75 
        s1=data[5] // 8
        s2=data[5] % 8
        if(s2>0):
            s2=1
        third_byte=s1+s2
        read_num1=s1+s2+5              #calculating the response bytes
#         print(read_num1)              #printing the number ofdata to be recived     
        data_rec=ser.read(read_num1)  #reading the read_count number of bytes from xr75
#         print(data_rec)                #printing the entire resived data
            
#         for i in range (read_num1):   #prinitng loop wise
#             print(" ")
#             print(hex(data_rec[i]))
        bit_count=0
        #:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        for a in parameter_find_list:
            if(check_only_parameter(a)):
                
                #print(a)
                
                for reg_num,reg_name in paramater_list.items():
                    if(a == reg_num):
                        name=reg_name
                        myjsonfile=open('xr75_to_e2.json','r')
                        jsondata=myjsonfile.read()   
                        obj=json.loads(jsondata)
                        for obj_keys,obj_values in obj.items():
                            keys=obj_keys
                            #print("\n name=",name,"  keys=",keys)
                            #print(name is keys)
                            if(name == obj_keys):    
                                return_list.append(obj_values)
#                                 print(obj_values)
                bit_count+=1
            else:
                if(((data_rec[3]>>bit_count) & 1)):
                    return_list.append('True')
                else:
                    return_list.append('False')
                
                bit_count+=1
    elif(data[1]==3):
        return_list=list(range(0,0))
        if(data[5]>1):
            return_list=list(range(0,0))
#             print("return_list",return_list)
            parameter_find_list=list(range(find_number,find_number+data[5]))
#             print(parameter_find_list)
            for a in parameter_find_list:
                if(check_only_parameter(a)):
                    for reg_num,reg_name in paramater_list.items():
                        if(a == reg_num):
                            name=reg_name
                            myjsonfile=open('xr75_to_e2.json','r')
                            jsondata=myjsonfile.read()   
                            obj=json.loads(jsondata)
                            for obj_keys,obj_values in obj.items():
                                keys=obj_keys
                                #print("\n name=",name,"  keys=",keys)
                                #print(name is keys)
                                if(name == obj_keys):    
                                    return_list.append(obj_values)
#                                     print(obj_values)
                else:
                    read_frame=list(range(0,0))
                    read_frame[0]=data[0]
                    read_frame[1]=data[1]
                    read_frame[2]=(find_number & 0xff00)>>8
                    read_frame[3]=find_number & 0x00ff
                    read_frame[4]=0x00
                    read_frame[5]=0x01
                    crc_byte=crc_modbus_1(read_frame)
                    crc_h=(crc_byte& 0xff00)>>8
                    crc_l=crc_byte & 0x00ff
                    read_frame.append(crc_l)
                    read_frame.append(crc_h)
                    return_list.append(read_again_xr75(read_frame))
                    
        else:
            return_list=list(range(0,0))
            a=find_number
            if(check_only_parameter(a)):
                for reg_num,reg_name in paramater_list.items():
                    if(a == reg_num):
                        name=reg_name
                        myjsonfile=open('xr75_to_e2.json','r')
                        jsondata=myjsonfile.read()   
                        obj=json.loads(jsondata)
                        for obj_keys,obj_values in obj.items():
                            keys=obj_keys
                            #print("\n name=",name,"  keys=",keys)
                            #print(name is keys)
                            if(name == obj_keys):    
#                                 print(obj_values)
                                return_list=list(range(0,0))
                                return_list.append(obj_values)
            else:
                read_frame=list(range(0,0))
                read_frame[0]=data[0]
                read_frame[1]=data[1]
                read_frame[2]=(find_number & 0xff00)>>8
                read_frame[3]=find_number & 0x00ff
                read_frame[4]=0x00
                read_frame[5]=0x01
                crc_byte=crc_modbus_1(read_frame)
                crc_h=(crc_byte& 0xff00)>>8
                crc_l=crc_byte & 0x00ff
                read_frame.append(crc_l)
                read_frame.append(crc_h)
                return_list.append(read_again_xr75(read_frame))
            
        
    
    return return_list





def check_only_parameter(number):
    parameter_list=[823,824,825,826,827,828,520,521,522,523,524,525,528,529.530,817,818,819,820,821,795,798,800,801,803,806,808,809,810,811,812,813,814,850,875,264,265,266,267,519,548,536,537,538,539,540,542,544,512,513,514,515,516,538,540,769,770,771,779,780,783,784,785,786,788,882,886,874,876,534,541,551]
    for i in parameter_list:
        if(i == number):
            return 1
    return 0
def crc_modbus_1(buf):
    num=len(buf)
    crc = 0xFFFF
    for pos in range (num):
        crc ^=int((buf[pos]))  
        for i in range (8, 0, -1):
            if ((crc & 0x0001) != 0):
                crc >>= 1 
                crc ^= 0xA001
            else:                         
                crc >>= 1
    return crc

def find_name(find_number):
    paramater_list={823:"Alarm_Option",
                    824:"High_Temp_Alarm_Threshold",
                    825:"Low_Temp_Alarm_Threshold",
                    826:"Alarm_Hysteresis",
                    827:"Alarm_Delay",
                    828:"Startup_Alarm_Delay",
                    520:"Dischargr_Air_Sensor_Failure",
                    521:"defrost_temp_sensor_failure",
                    522:"Sensor_3_Failure",
                    523:"Condensing_Unit_Sensor_Failure",
                    524:"High_Temp_Alarm",
                    525:"Low_Temp_Alarm",
                    528:"External_Alarm",
                    529:"Pressure_Switches_Trip(Severe_Alarm_Status)",
                    530:"Door_Open_Status",
                    817:"Auxiliary_Relay_Action",
                    818:"Auxiliary_Relay_Setpoint",
                    819:"Auxiliary_Relay_Differential",
                    820:"Auxiliary_Relay_Probe_Selection",
                    821:"Auxiliary_Relay_Switched_Off_During_Defrost",
                    795:"Defrost_Mode",
                    798:"Defrost_Termination_Setpoint",
                    800:"Defrost_Interval",
                    801:"Max_Defrost_Duration",
                    803:"Defrost_Delay",
                    806:"Drip_Time",
                    808:"Defrost_Delay_After_Fast_Freezing",
                    809:"Fan_Mode",
                    810:"Fan_Delay_after_defrost",
                    811:"Fan_Temp_Hystersis",
                    812:"Fan_StopTemp_Setpoint",
                    813:"Fan_Ontime",
                    814:"Fan_Offtime",
                    850:"Compressor_Fan_Status_When_Door_Open",
                    875:"Probe_Sensor_Type",
                    264:"Discharge_Air_Temp",
                    265:"Defrost_Temp_Read",
                    266:"Probe_3_Value",
                    267:"Probe_4_Value",
                    519:"DI1_Status",
                    548:"DI2_Status",
                    536:"Defrost_Status",
                    537:"Alarm_Status",
                    538:"Light_Status",
                    539:"Fan_Status",
                    540:"Aux_Relay_Status",
                    542:"Compressor_Status",
                    544:"Buzzer_Status",
                    512:"Device_Override",
                    513:"Defrost_Override",
                    514:"Pulldown_Override",
                    515:"Keyboard_LOCK/UN_LOCK_Status",
                    516:"Mute_Alarm_Override",
                    538:"Light_Override",
                    540:"Auxillary_Relay_Override",
                    769:"Differential_For_Cut_IN",
                    770:"Minimum_Setpoint_Limit",
                    771:"Maximum_Setpoint_Limit",
                    779:"Compressor_Startup_Delay",
                    780:"Minimum_Compressor_Off_Time",
                    783:"Pulldown_Duration",
                    784:"Pulldown_Setpoint",
                    785:"Failsafe_Compressor_ON_Time",
                    786:"Failsafe_Compressor_OFF_Time",
                    788:"Temp_Measurement_Unit",
                    882:"Active_Setpoint",
                    886:"Control_Setpoint",
                    874:"Modbus_Slave_Address",
                    876:"Controller_Enable",
                    534:"Control_Status",
                    541:"Neutral_Zone_Status",
                    551:"Energy_Saving_Status",        
        }
    for reg_number,reg_name in paramater_list:
        if(reg_number==  find_number):
            return reg_name
    return 0