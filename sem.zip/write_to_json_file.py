 
import serial
import time
import json
from pymodbus.client.sync import ModbusSerialClient

client = ModbusSerialClient(
    method='rtu',
    port= '/dev/ttyUSB0',
    baudrate=9600,
    timeout=3,
    parity='N',
    stopbits=1,
    bytesize=8
)


myjsonfile=open('e2_to_xr75.json','r')
jsondata=myjsonfile.read()

obj=json.loads(jsondata) #load from j son to objects
#print("length of paramaters in json file=",len(obj))


def crc_modbus(buf):
    num=len(buf)
    crc = 0xFFFF
    for pos in range (num):
        crc ^=int((buf[pos]))  
        for i in range (8, 0, -1):
            if ((crc & 0x0001) != 0):
                crc >>= 1 
                crc ^= 0xA001
            else:                         
                crc >>= 1
    
    return crc

#///////////////////////////////////////////////////////////

#while 1:

def reg_number(number,value):
    #recived_data=[0x00]*75
    recived_data=list(range(0,0))
    dec=[823,824,825,826,827,828,520,521,522,523,524,525,528,529,530,817,818,819,820,821,795,798,800,801,803,806,808,809,810,811,812,813,814,850,875,264,265,266,267,519,548,536,537,538,539,540,542,544,512,513,514,515,516,538,540,769,770,771,779,780,783,784,785,786,788,882,886,874,876,534,541,551,]
    #dec=[823,824,825,826,827,828,520,521,522,523,524,525,528,529,530,817,818,819,820,821,795,798,800,801,803,806,808,809,810,811,812,813,814,850,875,264,265,266,267,519,548,536,537,538,539,540,542,544,512,513,514,515,516,538,540,769,770,771,779,780,783,784,785,786,788,882,886,874,876,534,541,551]
#     print("the length of array= ",len(dec))
    name="name"
    i=0
    value_list=list(range(0,0))
    for reg_name,reg_value in obj.items():
        recived_data.append(reg_value)
        #print(i,recived_data[i])
        i+=1
        #print(value_list)
#     print(len(recived_data))
#     print(recived_data[37],recived_data[38])
#     print(obj.values)
    i=0
    
    for a in dec:
        if((i == 15) or (i==16)):
           i=i+1
           i=i-1
        elif (a == number):
            #while 1:
            #    j+=1
            if(value == 0xff):
#                 print(i,recived_data[i])
                recived_data[i]="on"
                
            else:
                recived_data[i]="off"
#         print("pos=",i,"num=",dec[i],a )
        i+=1
          
           
    obj["Alarm_Option"]=                   recived_data[0]
    obj['High_Temp_Alarm_Threshold']=      recived_data[1]
    obj["Low_Temp_Alarm_Threshold"]=       recived_data[2]
    obj["Alarm_Hystersis"]=                recived_data[3]
    obj["Alarm_Delay"]=                    recived_data[4]
    obj["Startup_Alarm_Delay"]=            recived_data[5]
    obj["Dischargr_Air_Sensor_Failure"]=   str(bool(recived_data[6]))
    obj["defrost_temp_sensor_failure"]=    str(bool(recived_data[7]))
    obj["Sensor_3_Failure"]=               str(bool(recived_data[8]))
    obj["Condensing_Unit_Sensor_Failure"]= str(bool(recived_data[9]))
    obj["High_Temp_Alarm"]=                str(bool(recived_data[10]))
    obj["Low_Temp_Alarm"]=                 str(bool(recived_data[11]))
    obj["External_Alarm"]=                 str(bool(recived_data[12]))
    obj["Pressure_Switches_Trip"]=         str(bool(recived_data[13]))
    obj["Door_Open_Status"]=               str(bool(recived_data[14]))
    obj["Condensing_Unit_High_Temp_Alarm"]=str(bool(recived_data[15]))
    obj["Condensing_Unit_Low_Temp_Alarm"]= str(bool(recived_data[16]))
    obj["Auxillary_Relay_Action"]=         str(bool(recived_data[17]))
    obj["Auxillary_Relay_Setpoint"]=       recived_data[18]
    obj["Auxillary_Relay_Differential"]=   recived_data[19]
    obj["Auxillary_Relay_Probe_Selection"]=recived_data[20]
    obj["Auxillary_Relay_Switched_Off_During_Defrost"]=str(bool(recived_data[21]))
    obj["Defrost_Mode"]=                   str(bool(recived_data[22]))
    obj["Defrost_Termination_Setpoint"]=   recived_data[23]
    obj["Defrost_Interval"]=               recived_data[24]
    obj["Max_Defrost_Duration"]=          recived_data[25]
    obj["Defrost_Delay"]=                  recived_data[26]
    obj["Drip_Time"]=                      recived_data[27]
    obj["Defrost_Delay_After_Fast_Freezing"]=recived_data[28]
    obj["Fan_Mode"]=                       recived_data[29]
    obj["Fan_Delay_After_Defrost"]=        recived_data[30]
    obj["Fan_Temp_Hystersis"]=             recived_data[31]
    obj["Fan_Stop_Temp_Setpoint"]=         recived_data[32]
    obj["Fan_Ontime"]=                     recived_data[33]
    obj["Fan_Offtime"]=                    recived_data[34]
    obj["Compressor_Fan_Status_When_Door_Open"]=recived_data[35]
    obj["Probe_Sensor_Type"]=              str(bool(recived_data[36]))
    obj["Discharge_Air_Temp"]=             recived_data[37]
    obj["Defrost_Temp_Read"]=              recived_data[38]
    obj["Probe_3_Value"]=                  int(recived_data[39])
    obj["Probe_4_Value"]=                  int(recived_data[40])
    obj["DI1_Status"]=                     str(bool(recived_data[41]))
    obj["DI2_Status"]=                     str(bool(recived_data[42]))
    obj["Defrost_Status"]=                 str(bool(recived_data[43]))
    obj["Alarm_Status"]=                   str(bool(recived_data[44]))
    obj["Light_Status"]=                   str(bool(recived_data[45]))
    obj["Fan_Status"]=                     str(bool(recived_data[46]))
    obj["Aux_Relay_Status"]=               str(bool(recived_data[47]))
    obj["Compressor_Status"]=              str(bool(recived_data[48]))
    obj["Buzzer_Status"]=                  str(bool(recived_data[49]))
    obj["Device_Override"]=                str(bool(recived_data[50]))
    obj["Defrost_Override"]=               str(bool(recived_data[51]))
    obj["Pulldown_Override"]=              str(bool(recived_data[52]))
    obj["Keyboard_LOCK/UN_LOCK_Status"]=   str(bool(recived_data[53]))
    obj["Mute_Alarm_Override"]=            str(bool(recived_data[54]))
    obj["Light_Override"]=                 str(bool(recived_data[55]))
    obj["Auxillary_Relay_Override"]=       str(bool(recived_data[56]))
    obj["Differential_For_Cut_In"]=        recived_data[57]
    obj["Minimum_Setpoint_Limit"]=         recived_data[58]
    obj["Maximum_Setpoint_Limit"]=         recived_data[59]
    obj["Compressor_Startup_Dalay"]=       recived_data[60]
    obj["Minimum_Compressor_Off_Time"]=    recived_data[61]
    obj["Pulldown_Duration"]=              recived_data[62]
    obj["Pulldown_Setpoint"]=              recived_data[63]
    obj["Failsafe_Compressor_ON_Time"]=    recived_data[64]
    obj["Failsafe_Compressor_OFF_Time"]=   recived_data[65]
    obj["Temp_Measurement_Unit"]=          str(bool(recived_data[66]))
    obj["Active_Setpoint"]=                recived_data[67]
    obj["Control_Setpoint"]=               recived_data[68]
    obj["Modbus_Slave_Address"]=           recived_data[69]
    obj["Controller_Enable"]=              recived_data[70]
    obj["Control_Status"]=                 str(bool(recived_data[71]))
    obj["Neutral_Zone_Status"]=            str(bool(recived_data[72]))
    obj["Energy_Saving_Status"]=           str(bool(recived_data[73]))
    obj["created_on"]="TIMESTAMP'2022-04-06T07:58:50.297247Z'"
    obj["modified_on"]="TIMESTAMP'2022-04-06T07:58:50.297247Z'"
    obj["\n"]="true"
   
    jsondata=json.dumps(obj,indent=5)  #dump to the same json file
    with open('e2_to_xr75.json',"w") as f:
        f.write(jsondata)
    return value


def writr_multiple_reg(data):
    #recived_data=[0x00]*75
    recived_data=list(range(0,0))
    dec=[823,824,825,826,827,828,520,521,522,523,524,525,528,529,530,817,818,819,820,821,795,798,800,801,803,806,808,809,810,811,812,813,814,850,875,264,265,266,267,519,548,536,537,538,539,540,542,544,512,513,514,515,516,538,540,769,770,771,779,780,783,784,785,786,788,882,886,874,876,534,541,551]
#     print("the length of array= ",len(dec))
    name="name"
    value_list=list(range(0,0))
    for reg_name,reg_value in obj.items():
        recived_data.append(reg_value)
        #print(value_list)
    value_list=list(range(data[3],(data[3]+data[5])))
    value_byte=7
    for i in value_list:
        for j in range(len(dec)):
            if(dec[j]==i):
#                 if(i==886):
#                     if client.connect():
#                         client.write_register(address=886,value=data[9],unit=2)
                time.sleep(2)
                h=(data[value_byte]<<8)
                value_byte+=1
                l=data[value_byte]
                recived_data[j]=h|l 
            #a1=int(recived_data[0]),   
                obj["Alarm_Option"]=                   recived_data[0]
                obj['High_Temp_Alarm_Threshold']=      recived_data[1]
                obj["Low_Temp_Alarm_Threshold"]=       recived_data[2]
                obj["Alarm_Hystersis"]=                recived_data[3]
                obj["Alarm_Delay"]=                    recived_data[4]
                obj["Startup_Alarm_Delay"]=            recived_data[5]
                obj["Dischargr_Air_Sensor_Failure"]=   str(bool(recived_data[6]))
                obj["defrost_temp_sensor_failure"]=    str(bool(recived_data[7]))
                obj["Sensor_3_Failure"]=               str(bool(recived_data[8]))
                obj["Condensing_Unit_Sensor_Failure"]= str(bool(recived_data[9]))
                obj["High_Temp_Alarm"]=                str(bool(recived_data[10]))
                obj["Low_Temp_Alarm"]=                 str(bool(recived_data[11]))
                obj["External_Alarm"]=                 str(bool(recived_data[12]))
                obj["Pressure_Switches_Trip"]=         str(bool(recived_data[13]))
                obj["Door_Open_Status"]=               str(bool(recived_data[14]))
                obj["Condensing_Unit_High_Temp_Alarm"]=str(bool(1)) #recived_data[15]
                obj["Condensing_Unit_Low_Temp_Alarm"]= str(bool(0))#recived_data[16]
                obj["Auxillary_Relay_Action"]=         str(bool(recived_data[15]))
                obj["Auxillary_Relay_Setpoint"]=       recived_data[16]
                obj["Auxillary_Relay_Differential"]=   recived_data[17]
                obj["Auxillary_Relay_Probe_Selection"]=recived_data[18]
                obj["Auxillary_Relay_Switched_Off_During_Defrost"]=str(bool(recived_data[19]))
                obj["Defrost_Mode"]=                   str(bool(recived_data[20]))
                obj["Defrost_Termination_Setpoint"]=   recived_data[21]
                obj["Defrost_Interval"]=               recived_data[22]
                obj["Max_Defrost_Duration"]=          recived_data[23]
                obj["Defrost_Delay"]=                  recived_data[24]
                obj["Drip_Time"]=                      recived_data[25]
                obj["Defrost_Delay_After_Fast_Freezing"]=recived_data[26]
                obj["Fan_Mode"]=                       recived_data[27]
                obj["Fan_Delay_After_Defrost"]=        recived_data[28]
                obj["Fan_Temp_Hystersis"]=             recived_data[29]
                obj["Fan_Stop_Temp_Setpoint"]=         recived_data[30]
                obj["Fan_Ontime"]=                     recived_data[31]
                obj["Fan_Offtime"]=                    recived_data[32]
                obj["Compressor_Fan_Status_When_Door_Open"]=recived_data[33]
                obj["Probe_Sensor_Type"]=              str(bool(recived_data[34]))
                obj["Discharge_Air_Temp"]=             recived_data[35]
                obj["Defrost_Temp_Read"]=              recived_data[36]
                obj["Probe_3_Value"]=                  int(recived_data[37])
                obj["Probe_4_Value"]=                  int(recived_data[38])
                obj["DI1_Status"]=                     str(bool(recived_data[39]))
                obj["DI2_Status"]=                     str(bool(recived_data[40]))
                obj["Defrost_Status"]=                 str(bool(recived_data[41]))
                obj["Alarm_Status"]=                   str(bool(recived_data[42]))
                obj["Light_Status"]=                   str(bool(recived_data[43]))
                obj["Fan_Status"]=                     str(bool(recived_data[44]))
                obj["Aux_Relay_Status"]=               str(bool(recived_data[45]))
                obj["Compressor_Status"]=              str(bool(recived_data[46]))
                obj["Buzzer_Status"]=                  str(bool(recived_data[47]))
                obj["Device_Override"]=                str(bool(recived_data[48]))
                obj["Defrost_Override"]=               str(bool(recived_data[49]))
                obj["Pulldown_Override"]=              str(bool(recived_data[50]))
                obj["Keyboard_LOCK/UN_LOCK_Status"]=   str(bool(recived_data[51]))
                obj["Mute_Alarm_Override"]=            str(bool(recived_data[52]))
                obj["Light_Override"]=                 str(bool(recived_data[53]))
                obj["Auxillary_Relay_Override"]=       str(bool(recived_data[54]))
                obj["Differential_For_Cut_In"]=        recived_data[55]
                obj["Minimum_Setpoint_Limit"]=         recived_data[56]
                obj["Maximum_Setpoint_Limit"]=         recived_data[57]
                obj["Compressor_Startup_Dalay"]=       recived_data[58]
                obj["Minimum_Compressor_Off_Time"]=    recived_data[59]
                obj["Pulldown_Duration"]=              recived_data[60]
                obj["Pulldown_Setpoint"]=              recived_data[61]
                obj["Failsafe_Compressor_ON_Time"]=    recived_data[62]
                obj["Failsafe_Compressor_OFF_Time"]=   recived_data[63]
                obj["Temp_Measurement_Unit"]=          str(bool(recived_data[64]))
                obj["Active_Setpoint"]=                recived_data[65]
                obj["Control_Setpoint"]=               recived_data[66]
                obj["Modbus_Slave_Address"]=           recived_data[67]
                obj["Controller_Enable"]=              recived_data[68]
                obj["Control_Status"]=                 str(bool(recived_data[69]))
                obj["Neutral_Zone_Status"]=            str(bool(recived_data[70]))
                obj["Energy_Saving_Status"]=           str(bool(recived_data[71]))
                obj["created_on"]="TIMESTAMP'2022-04-06T07:58:50.297247Z'"
                obj["modified_on"]="TIMESTAMP'2022-04-06T07:58:50.297247Z'"
                obj["\n"]="true"
               
    jsondata=json.dumps(obj,indent=5)  #dump to the same json file
    with open('e2_to_xr75.json',"w") as f:
        f.write(jsondata)
    

       
       
       
def find_name(find_number):
    paramater_list={823:"Alarm_Option",
                    824:"High_Temp_Alarm_Threshold",
                    825:"Low_Temp_Alarm_Threshold",
                    826:"Alarm_Hysteresis",
                    827:"Alarm_Delay",
                    828:"Startup_Alarm_Delay",
                    520:"Dischargr_Air_Sensor_Failure",
                    521:"defrost_temp_sensor_failure",
                    522:"Sensor_3_Failure",
                    523:"Condensing_Unit_Sensor_Failure",
                    524:"High_Temp_Alarm",
                    525:"Low_Temp_Alarm",
                    528:"External_Alarm",
                    529:"Pressure_Switches_Trip(Severe_Alarm_Status)",
                    530:"Door_Open_Status",
                    817:"Auxiliary_Relay_Action",
                    818:"Auxiliary_Relay_Setpoint",
                    819:"Auxiliary_Relay_Differential",
                    820:"Auxiliary_Relay_Probe_Selection",
                    821:"Auxiliary_Relay_Switched_Off_During_Defrost",
                    795:"Defrost_Mode",
                    798:"Defrost_Termination_Setpoint",
                    800:"Defrost_Interval",
                    801:"Max_Defrost_Duration",
                    803:"Defrost_Delay",
                    806:"Drip_Time",
                    808:"Defrost_Delay_After_Fast_Freezing",
                    809:"Fan_Mode",
                    810:"Fan_Delay_after_defrost",
                    811:"Fan_Temp_Hystersis",
                    812:"Fan_StopTemp_Setpoint",
                    813:"Fan_Ontime",
                    814:"Fan_Offtime",
                    850:"Compressor_Fan_Status_When_Door_Open",
                    875:"Probe_Sensor_Type",
                    264:"Discharge_Air_Temp",
                    265:"Defrost_Temp_Read",
                    266:"Probe_3_Value",
                    267:"Probe_4_Value",
                    519:"DI1_Status",
                    548:"DI2_Status",
                    536:"Defrost_Status",
                    537:"Alarm_Status",
                    538:"Light_Status",
                    539:"Fan_Status",
                    540:"Aux_Relay_Status",
                    542:"Compressor_Status",
                    544:"Buzzer_Status",
                    512:"Device_Override",
                    513:"Defrost_Override",
                    514:"Pulldown_Override",
                    515:"Keyboard_LOCK/UN_LOCK_Status",
                    516:"Mute_Alarm_Override",
                    538:"Light_Override",
                    540:"Auxillary_Relay_Override",
                    769:"Differential_For_Cut_IN",
                    770:"Minimum_Setpoint_Limit",
                    771:"Maximum_Setpoint_Limit",
                    779:"Compressor_Startup_Delay",
                    780:"Minimum_Compressor_Off_Time",
                    783:"Pulldown_Duration",
                    784:"Pulldown_Setpoint",
                    785:"Failsafe_Compressor_ON_Time",
                    786:"Failsafe_Compressor_OFF_Time",
                    788:"Temp_Measurement_Unit",
                    882:"Active_Setpoint",
                    886:"Control_Setpoint",
                    874:"Modbus_Slave_Address",
                    876:"Controller_Enable",
                    534:"Control_Status",
                    541:"Neutral_Zone_Status",
                    551:"Energy_Saving_Status",        
        }
    for reg_number,reg_name in paramater_list:
        if(reg_number==  find_number):
            return reg_name
    return 0     

       
       
       
 