 
import serial
import time
import json
import time
from pymodbus.client.sync import ModbusSerialClient

client = ModbusSerialClient(
    method='rtu',
    port= '/dev/ttyUSB0',
    baudrate=9600,
    timeout=3,
    parity='N',
    stopbits=1,
    bytesize=8
)

def crc_modbus(buf):
    num=len(buf)
    crc = 0xFFFF
    for pos in range (num):
        crc ^=int((buf[pos]))  
        for i in range (8, 0, -1):
            if ((crc & 0x0001) != 0):
                crc >>= 1 
                crc ^= 0xA001
            else:                         
                crc >>= 1
    
    return crc


def find_reg_num(find_name):
    paramater_list_py={823:"Alarm_Option",
                    824:"High_Temp_Alarm_Threshold",
                    825:"Low_Temp_Alarm_Threshold",
                    826:"Alarm_Hysteresis",
                    827:"Alarm_Delay",
                    828:"Startup_Alarm_Delay",
                    520:"Dischargr_Air_Sensor_Failure",
                    521:"defrost_temp_sensor_failure",
                    522:"Sensor_3_Failure",
                    523:"Condensing_Unit_Sensor_Failure",
                    524:"High_Temp_Alarm",
                    525:"Low_Temp_Alarm",
                    528:"External_Alarm",
                    529:"Pressure_Switches_Trip(Severe_Alarm_Status)",
                    530:"Door_Open_Status",
                    817:"Auxiliary_Relay_Action",
                    818:"Auxiliary_Relay_Setpoint",
                    819:"Auxiliary_Relay_Differential",
                    820:"Auxiliary_Relay_Probe_Selection",
                    821:"Auxiliary_Relay_Switched_Off_During_Defrost",
                    795:"Defrost_Mode",
                    798:"Defrost_Termination_Setpoint",
                    800:"Defrost_Interval",
                    801:"Max_Defrost_Duration",
                    803:"Defrost_Delay",
                    806:"Drip_Time",
                    808:"Defrost_Delay_After_Fast_Freezing",
                    809:"Fan_Mode",
                    810:"Fan_Delay_after_defrost",
                    811:"Fan_Temp_Hystersis",
                    812:"Fan_StopTemp_Setpoint",
                    813:"Fan_Ontime",
                    814:"Fan_Offtime",
                    850:"Compressor_Fan_Status_When_Door_Open",
                    875:"Probe_Sensor_Type",
                    264:"Discharge_Air_Temp",
                    265:"Defrost_Temp_Read",
                    266:"Probe_3_Value",
                    267:"Probe_4_Value",
                    519:"DI1_Status",
                    548:"DI2_Status",
                    536:"Defrost_Status",
                    537:"Alarm_Status",
                    538:"Light_Status",
                    539:"Fan_Status",
                    540:"Aux_Relay_Status",
                    542:"Compressor_Status",
                    544:"Buzzer_Status",
                    512:"Device_Override",
                    513:"Defrost_Override",
                    514:"Pulldown_Override",
                    515:"Keyboard_LOCK/UN_LOCK_Status",
                    516:"Mute_Alarm_Override",
                    538:"Light_Override",
                    540:"Auxillary_Relay_Override",
                    769:"Differential_For_Cut_IN",
                    770:"Minimum_Setpoint_Limit",
                    771:"Maximum_Setpoint_Limit",
                    779:"Compressor_Startup_Delay",
                    780:"Minimum_Compressor_Off_Time",
                    783:"Pulldown_Duration",
                    784:"Pulldown_Setpoint",
                    785:"Failsafe_Compressor_ON_Time",
                    786:"Failsafe_Compressor_OFF_Time",
                    788:"Temp_Measurement_Unit",
                    882:"Active_Setpoint",
                    886:"Control_Setpoint",
                    874:"Modbus_Slave_Address",
                    876:"Controller_Enable",
                    534:"Control_Status",
                    541:"Neutral_Zone_Status",
                    551:"Energy_Saving_Status",        
    }
    for reg_number,reg_name in paramater_list_py.items():
        if(reg_name ==  find_name):
            return reg_number
    return 0

myjsonfile=open('e2_to_xr75.json','r')
jsondata=myjsonfile.read()

obj_e2_to_xr75=json.loads(jsondata) #load from j son to objects
#print("length of paramaters in json file=",len(obj))
e2_to_xr75_values=(list(range(0,0)))
#print(obj_e2_to_xr75.keys())
#print(obj_e2_to_xr75.values())
for values in obj_e2_to_xr75.values():
    e2_to_xr75_values.append(values)
    
len_of_json_file=len(e2_to_xr75_values)
myjsonfile=open('xr75_to_e2.json','r')
jsondata=myjsonfile.read()
obj_xr75_to_e2=json.loads(jsondata)


xr75_to_e2_values=(list(range(0,0)))
xr75_to_e2_names=(list(range(0,0)))
for values in obj_xr75_to_e2.values():
    xr75_to_e2_values.append(values)
    
for keys in obj_e2_to_xr75.keys():
    xr75_to_e2_names.append(keys)
data=list(range(0,0))
j=0
for i in range(len_of_json_file):
    if(e2_to_xr75_values[i] != xr75_to_e2_values[i]):
        if(i<74):
            print(xr75_to_e2_names[i])
            reg_num=find_reg_num(xr75_to_e2_names[i])
            h=(reg_num & 0xff00)>>8
            l=reg_num & 0xff
            if(reg_num>=500 and reg_num<=600):
                fc=0x5
            else:
                fc=0x10
            addr=2
            #fourth_byte=e2_to_xr75_values[i]
            fourth_byte=e2_to_xr75_values[i]
            
            if((fourth_byte == 'True') or (fourth_byte == 'on')):
                fourth_byte=0xff
            elif((fourth_byte == 'False') or (fourth_byte == 'off')):
                fourth_byte=0x00

            
            fifth_byte=0x00
            
            data.clear()
            data.append(addr)
            data.append(fc)
            data.append(h)
            data.append(l)
            data.append(fourth_byte)
            data.append(fifth_byte)
            crc_value=crc_modbus(data)
            
            crc_h=(crc_value & 0xff00)>>8
            crc_l=crc_value & 0xff
            data.append(crc_l)
            data.append(crc_h)
            #------------------------
            
            if client.connect():

#                 res = client.read_holding_registers(address=reg_num, count=1, unit=2)# address = start register address, count = lenght, unit = Device ID
#                 if not res.isError():
#                     print(res.registers)
#                 else:
#                     print(res)
                client.write_register(address=reg_num,value=fourth_byte,unit=2)
                time.sleep(2)
                
#                 res = client.read_holding_registers(address=reg_num, count=1, unit=2)# address = start register address, count = lenght, unit = Device ID
#                 if not res.isError():
#                     print(res.registers)
# 
#                 else:
#                     print(res)
                    
              
            else:
                print('Cannot connect to the Modbus Server/Slave')

            #------------------------
            """
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data)
            print(data)
            data.clear()
            
            data_1=ser.read(5)
            print(data_1)
            """

#additional program
#::::::::::::::::::::::::
#print(obj.keys())
#print(obj.values())

#;;;;;;;;;;;;;;;;;;;;

#///////////////////////////////////////////////////////////

#while 1:
a=0
recived_data=[0x00]*75
dec=[823,824,825,826,827,828,520,521,522,523,524,525,528,529,530,817,818,819,820,821,795,798,800,801,803,806,808,809,810,811,812,813,814,850,875,264,265,266,267,519,548,536,537,538,539,540,542,544,512,513,514,515,516,538,540,769,770,771,779,780,783,784,785,786,788,882,886,874,876,534,541,551]
print("the length of array= ",len(dec))
for i in range(len(dec)):
    ab=i
    #print("holding reister number=",dec[i])
    hexa=int(dec[i])
    #print(hexa)
    hexa_h=hex((int(hexa))&0xFF00)
    hexa_l=hex((int(hexa))&0x00FF)
    hexa_h=hex(((int)(hexa))>>8)
    #print(hexa_h,hexa_l)
    
    if(hexa>=500 and hexa<=600):
        fc=0x1
    else:
        fc=0x3
    
    add=0x2
    #fc=0x3
    hexa_h=(((hexa)&0xFF00)>>8)
    hexa_l=((hexa)&0xFF)
    read_h=0x0
    read_l=0x1
    data=[add,fc,hexa_h,hexa_l,read_h,read_l] #array this will send to xr75 for reading perticular parameters
    #for i in range(len(data)):
        #print(hex(data[i]))
    #calculating crc higher byte and crc-lower byte.....................
    rec_data=crc_modbus(data)
    crc_l=rh=(rec_data & 0xFF00)>>8
    crc_h=rl=(rec_data & 0X00FF)
    rl<<=8
    #data=rh|rl
    #print(hex(rh),hex(rl),hex(data))
    #print("crc=",hex(crc_h),hex(crc_l))
    
    if(hexa>=500 and hexa<=600):
        read_h<<=8
        count=read_h|read_l
        c1=count//8
        c2=count%8
        if(c2>0):
            c1+=1
        read_count=c1+5   
    else:
        read_count=((read_l*2)+5) #calculating the response bytes
        
    
    to_send=[(add),(fc),(hexa_h),(hexa_l),(read_h),(read_l),(crc_h),(crc_l)]
    #print("request frame =",(add),(fc),(hexa_h),(hexa_l),(read_h),(read_l),(crc_h),(crc_l))
    
    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    ser.write(to_send)                #writing the requested data to xr75
     

    
    #print(read_count)              #printing the number ofdata to be recived     
    data_rec=ser.read(read_count)  #reading the read_count number of bytes from xr75
    #print(data_rec)                #printing the entire resived data
    #for i in range (read_count):
        #print(hex(data_rec[i]))
     
    print()
    if(data_rec[2]==2):
        h=data_rec[3]
        l=data_rec[4]
        h<<=8
        recived_data[ab]=h|l
        #print("writing ",hex(recived_data[ab]))
        #print("reg=",dec[i],"value=",recived_data[ab],ab)
    else:
        h=data_rec[3]
        recived_data[ab]=h
        #print("writing ",hex(recived_data[ab]))
        #print("reg=",dec[i],"value=",recived_data[ab],ab)
    
    #data_rec.remove[0:2]
    #del data_rec[9:11]
    #recived_data.append(data_rec)
    #recived_data=recived_data + data_rec
    
    
    
    
    print("................................................")
    
         
#for i in range(len(recived_data)):
    #print(recived_data[i])
#print(type(recived_data[0]))
# print("512 = ",recived_data[48],"515 = ",recived_data[51])
a1=int(recived_data[0]),

obj_e2_to_xr75["Alarm_Option"]=                   recived_data[0]
obj_e2_to_xr75['High_Temp_Alarm_Threshold']=      recived_data[1]
obj_e2_to_xr75["Low_Temp_Alarm_Threshold"]=       recived_data[2]
obj_e2_to_xr75["Alarm_Hystersis"]=                recived_data[3]
obj_e2_to_xr75["Alarm_Delay"]=                    recived_data[4]
obj_e2_to_xr75["Startup_Alarm_Delay"]=            recived_data[5]
obj_e2_to_xr75["Dischargr_Air_Sensor_Failure"]=   str(bool(recived_data[6]))
obj_e2_to_xr75["defrost_temp_sensor_failure"]=    str(bool(recived_data[7]))
obj_e2_to_xr75["Sensor_3_Failure"]=               str(bool(recived_data[8]))
obj_e2_to_xr75["Condensing_Unit_Sensor_Failure"]= str(bool(recived_data[9]))
obj_e2_to_xr75["High_Temp_Alarm"]=                str(bool(recived_data[10]))
obj_e2_to_xr75["Low_Temp_Alarm"]=                 str(bool(recived_data[11]))
obj_e2_to_xr75["External_Alarm"]=                 str(bool(recived_data[12]))
obj_e2_to_xr75["Pressure_Switches_Trip"]=         str(bool(recived_data[13]))
obj_e2_to_xr75["Door_Open_Status"]=               str(bool(recived_data[14]))
obj_e2_to_xr75["Condensing_Unit_High_Temp_Alarm"]=str(bool(1)) #recived_data[15]
obj_e2_to_xr75["Condensing_Unit_Low_Temp_Alarm"]= str(bool(0))#recived_data[16]
obj_e2_to_xr75["Auxillary_Relay_Action"]=         str(bool(recived_data[15]))
obj_e2_to_xr75["Auxillary_Relay_Setpoint"]=       recived_data[16]
obj_e2_to_xr75["Auxillary_Relay_Differential"]=   recived_data[17]
obj_e2_to_xr75["Auxillary_Relay_Probe_Selection"]=recived_data[18]
obj_e2_to_xr75["Auxillary_Relay_Switched_Off_During_Defrost"]=str(bool(recived_data[19]))
obj_e2_to_xr75["Defrost_Mode"]=                   str(bool(recived_data[20]))
obj_e2_to_xr75["Defrost_Termination_Setpoint"]=   recived_data[21]
obj_e2_to_xr75["Defrost_Interval"]=               recived_data[22]
obj_e2_to_xr75["Max_Defrost_Duration"]=          recived_data[23]
obj_e2_to_xr75["Defrost_Delay"]=                  recived_data[24]
obj_e2_to_xr75["Drip_Time"]=                      recived_data[25]
obj_e2_to_xr75["Defrost_Delay_After_Fast_Freezing"]=recived_data[26]
obj_e2_to_xr75["Fan_Mode"]=                       recived_data[27]
obj_e2_to_xr75["Fan_Delay_After_Defrost"]=        recived_data[28]
obj_e2_to_xr75["Fan_Temp_Hystersis"]=             recived_data[29]
obj_e2_to_xr75["Fan_Stop_Temp_Setpoint"]=         recived_data[30]
obj_e2_to_xr75["Fan_Ontime"]=                     recived_data[31]
obj_e2_to_xr75["Fan_Offtime"]=                    recived_data[32]
obj_e2_to_xr75["Compressor_Fan_Status_When_Door_Open"]=recived_data[33]
obj_e2_to_xr75["Probe_Sensor_Type"]=              str(bool(recived_data[34]))
obj_e2_to_xr75["Discharge_Air_Temp"]=             recived_data[35]
obj_e2_to_xr75["Defrost_Temp_Read"]=              recived_data[36]
obj_e2_to_xr75["Probe_3_Value"]=                  int(recived_data[37])
obj_e2_to_xr75["Probe_4_Value"]=                  int(recived_data[38])
obj_e2_to_xr75["DI1_Status"]=                     str(bool(recived_data[39]))
obj_e2_to_xr75["DI2_Status"]=                     str(bool(recived_data[40]))
obj_e2_to_xr75["Defrost_Status"]=                 str(bool(recived_data[41]))
obj_e2_to_xr75["Alarm_Status"]=                   str(bool(recived_data[42]))
obj_e2_to_xr75["Light_Status"]=                   str(bool(recived_data[43]))
obj_e2_to_xr75["Fan_Status"]=                     str(bool(recived_data[44]))
obj_e2_to_xr75["Aux_Relay_Status"]=               str(bool(recived_data[45]))
obj_e2_to_xr75["Compressor_Status"]=              str(bool(recived_data[46]))
obj_e2_to_xr75["Buzzer_Status"]=                  str(bool(recived_data[47]))
obj_e2_to_xr75["Device_Override"]=                str(bool(recived_data[48]))
obj_e2_to_xr75["Defrost_Override"]=               str(bool(recived_data[49]))
obj_e2_to_xr75["Pulldown_Override"]=              str(bool(recived_data[50]))
obj_e2_to_xr75["Keyboard_LOCK/UN_LOCK_Status"]=   str(bool(recived_data[51]))
obj_e2_to_xr75["Mute_Alarm_Override"]=            str(bool(recived_data[52]))
obj_e2_to_xr75["Light_Override"]=                 str(bool(recived_data[53]))
obj_e2_to_xr75["Auxillary_Relay_Override"]=       str(bool(recived_data[54]))
obj_e2_to_xr75["Differential_For_Cut_In"]=        recived_data[55]
obj_e2_to_xr75["Minimum_Setpoint_Limit"]=         recived_data[56]
obj_e2_to_xr75["Maximum_Setpoint_Limit"]=         recived_data[57]
obj_e2_to_xr75["Compressor_Startup_Dalay"]=       recived_data[58]
obj_e2_to_xr75["Minimum_Compressor_Off_Time"]=    recived_data[59]
obj_e2_to_xr75["Pulldown_Duration"]=              recived_data[60]
obj_e2_to_xr75["Pulldown_Setpoint"]=              recived_data[61]
obj_e2_to_xr75["Failsafe_Compressor_ON_Time"]=    recived_data[62]
obj_e2_to_xr75["Failsafe_Compressor_OFF_Time"]=   recived_data[63]
obj_e2_to_xr75["Temp_Measurement_Unit"]=          str(bool(recived_data[64]))
obj_e2_to_xr75["Active_Setpoint"]=                recived_data[65]
obj_e2_to_xr75["Control_Setpoint"]=               recived_data[66]
obj_e2_to_xr75["Modbus_Slave_Address"]=           recived_data[67]
obj_e2_to_xr75["Controller_Enable"]=              recived_data[68]
obj_e2_to_xr75["Control_Status"]=                 str(bool(recived_data[69]))
obj_e2_to_xr75["Neutral_Zone_Status"]=            str(bool(recived_data[70]))
obj_e2_to_xr75["Energy_Saving_Status"]=           str(bool(recived_data[71]))
obj_e2_to_xr75["created_on"]="TIMESTAMP'2022-04-06T07:58:50.297247Z'"
obj_e2_to_xr75["modified_on"]="TIMESTAMP'2022-04-06T07:58:50.297247Z'"
obj_e2_to_xr75["\n"]="true"

#with open('Modbus1.json',"w") as f:
jsondata=json.dumps(obj_e2_to_xr75,indent=5)  #dump to the same json file
with open('xr75_to_e2.json',"w") as f:
    f.write(jsondata)


