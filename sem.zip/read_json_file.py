#check in the updated json file and send the latest value 
import serial
import time
import json
from paramater_number import find_parameter_name,check_in_list
from write_to_json_file import *
# from write_to_json_file import reg_number
#calculate the crc value of each frames 
def crc_modbus(buf):
    num=len(buf)
    crc = 0xFFFF
    for pos in range (num):
        crc ^=int((buf[pos]))  
        for i in range (8, 0, -1):
            if ((crc & 0x0001) != 0):
                crc >>= 1 
                crc ^= 0xA001
            else:                         
                crc >>= 1
    return crc

def read_from_file(data,parameter_number):
                               #load from j son to objects
    if(data[1]==1):
        e2_send_frame=function_code_1(data,parameter_number)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(e2_send_frame)
    elif (data[1]==2):
        e2_send_frame=function_code_1(data,parameter_number)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(e2_send_frame)  
    elif (data[1]==3):
        e2_send_frame=function_code_3(data,parameter_number)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(e2_send_frame)

    elif(data[1]==5):
        e2_send_frame=function_code_5(data,parameter_number)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(e2_send_frame)   
    elif (data[1]==16):
        e2_send_frame=function_code_16(data,parameter_number)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(e2_send_frame)
    







def function_code_1(data,parameter_number):
    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    ser.write(data)                #writing the requested data to xr75
     
    s1=data[5]//8
    s2=data[5]%8
    if(s2>0):
        s2=1
    read_num1=s1+s2+5              #calculating the response bytes
#         print(read_num1)              #printing the number ofdata to be recived     
    data_rec=ser.read(read_num1)
    print("data from rx75")
    for i in data_rec:
        print(hex(i))

    """
    s1=data[5]//8
    s2=data[5]%8
    if(s2>0):
        s2=1
    responce_num_1=s1+s2+5
    third_byte=s1+s2                      #third byte is ready
    buff_frame=list(range(0,0))
#     print(parameter_number,"count",data[5])
    bool_variable_names=find_parameter_name(parameter_number,data[5],data)  
    
#     print(bool_variable_names) 
    
    
    variable_1=0
    variable_2=0
    variable_3=0
    variable_4=0
    pos=0

    for i in bool_variable_names:
        if(pos<=7 and pos>=0):
            if(i == 'True'):
                variable_1=variable_1 |(1 << pos)
                pos+=1
            elif(i == 'False'):
                variable_1=variable_1 & ~(1<<pos)
                pos+=1
            
        elif(pos<=15 and pos>=8):
            if(i == 'True' ):
                variable_2=variable_2|(1 << (pos-8))
                pos+=1
            elif(i == 'False'):
                variable_2=variable_2 & ~(1<<(pos-8))
                pos+=1
            
        elif(pos<=23 and pos >=16):
            if(i == 'True' ):
                variable_3=variable_3 | (1 << (pos-16))
                pos+=1
            elif(i == 'False'):
                variable_3=variable_3 & ~(1<<(pos-16))
                pos+=1
        elif(pos<=31 and pos >=24):
            if(i == 'True' ):
                variable_4=variable_4 | (1 << (pos-24))
                pos+=1
            elif(i == 'False'):
                variable_4=variable_4 & ~(1<<(pos-24))
                pos+=1
    if(third_byte==1):
        fourth_byte=variable_1
        buff_frame.append(data[0])
        buff_frame.append(data[1])
        buff_frame.append(third_byte)
        buff_frame.append(fourth_byte)
    elif(third_byte==2):
        h=variable_1#&0xff00
        l=variable_2#&0x00ff
        #h=h>>8
        buff_frame.append(data[0])
        buff_frame.append(data[1])
        buff_frame.append(third_byte)
        buff_frame.append(h)
        buff_frame.append(l)
    elif(third_byte==3):
        h1=variable_1#&0xff0000
        h=variable_2#&0x00ff00
        l=variable_3#&0x0000ff
        #h1=h1>>16
        #h=h>>8
        buff_frame.append(data[0])
        buff_frame.append(data[1])
        buff_frame.append(third_byte)
        buff_frame.append(h1)
        buff_frame.append(h)
        buff_frame.append(l)
    elif( third_byte == 4 ):
        h2=variable_1#&0xff0000
        h1=variable_2#&0x00ff00
        h=variable_3#&0x0000ff
        l=variable_4
         
        buff_frame.append(data[0])
        buff_frame.append(data[1])
        buff_frame.append(third_byte)
        buff_frame.append(h2)
        buff_frame.append(h1)
        buff_frame.append(h)
        buff_frame.append(l)
        

    crc_value=crc_modbus(buff_frame)
    
    crc_h=crc_value&0xff00
    crc_h=crc_h>>8
    crc_l=crc_value&0x00ff
    
    buff_frame.append(crc_l)
    buff_frame.append(crc_h)
    print("data from xr75_to_e2 json_file")   
    for i in range (len(buff_frame)):
#         print(" ")
        print(hex(buff_frame[i]))
    """
    return data_rec
    
def function_code_3(data,parameter_number):
    data_rec=0
    if(data[2] == 3 and data[3] == 118 and data[4] == 0 and data[5] == 1):
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)
        read_count=7
    else:
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data) 
        read_count=((data[5]*2)+5) #calculating the response bytes
     
#         print(read_count)              #printing the number ofdata to be recived     
    data_rec=ser.read(read_count)
    print("data from rx75")
    for i in data_rec:
        print(hex(i))
    """
    third_byte=(data[5]*2)
    buff_frame=[data[0],data[1],third_byte]
    read_count=((data[5]*2)+5)
#     print(parameter_number,"count",data[5])
    bool_variable_names=find_parameter_name(parameter_number,data[5],data)
    if(data[5]==1):
        byte=bool_variable_names[0]
        fourth_byte=(byte & 0xff00)>>8
        fifth_byte=byte & 0x00ff
        buff_frame=[data[0],data[1],third_byte,fourth_byte,fifth_byte]
#         print(buff_frame)
        crc_byte=crc_modbus(buff_frame)
        crc_h=(crc_byte&0xff00)>>8
        crc_l=crc_byte & 0x00ff
        buff_frame.append(crc_l)
        buff_frame.append(crc_h)
        
    elif(data[5]>1):
        number_of_bytes=data[5]*2
        num_list=list(range(0,0))
        for i in range(data[5]):
            value=bool_variable_names[i]
            high=(int(value) & 0xff00)>>8
            low=int(value) & 0x00ff
            buff_frame.append(high)
            buff_frame.append(low)
#         print(buff_frame)
        crc_byte=crc_modbus(buff_frame)
        crc_h=(crc_byte&0xff00)>>8
        crc_l=crc_byte & 0x00ff
        buff_frame.append(crc_l)
        buff_frame.append(crc_h)
    print("data from xr75_to_e2 json_file")   
    for i in range (len(buff_frame)):
#         print(" ")
        print(hex(buff_frame[i]))
    """
    return data_rec
    
     
    
    
def function_code_5(data,parameter_number):
    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    ser.write(data)
    read_count=8
    
    
    data_rec=ser.read(read_count)
    print("data from rx75")
    for i in data_rec:
#         print(" ")
        print(hex(i))


    """
    present=check_in_list(parameter_number)               #this will check the parameter number in the json file and return '1' when found,return '0' when not found
#     print(data,parameter_number)
    if(present == 1): 
        return_value=reg_number(parameter_number,data[4])            #read data from json file which is alrady in the another therad 
    else :
        return_value=read_again_xr75(data)
    print("data from xr75_to_e2 json_file")   
    for i in data:
#         print(" ")
        print(hex(i))
    """
    return data_rec

def function_code_16(data,parameter_number):
    read_count =((data[5]*2)+9)
    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    ser.write(data)                #writing the requested data to xr75       
    
#         print("fc 16 responce will be 8 bytes only ")
    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    data_rec=ser.read(8)  #reading the read_count number of bytes from xr75
    #print(data_rec)                #printing the entire resived data
#         print("response from xr75")   
    print("data from rx75")
    for i in range (8):   #prinitng loop wise
#         print(" ")
        print(hex(data_rec[i])) 
    
    
    """
    writr_multiple_reg(data)
    buff_1=list(range(0,6))
    for i in range (6):
        buff_1[i]=data[i]
    
    
    crc_bytes=crc_modbus(buff_1)
    crc_h=(crc_bytes & 0xff00)>>8
    crc_l=crc_bytes & 0x00ff
    buff_1.append(crc_l)    
    buff_1.append(crc_h)
    print("data from xr75_to_e2 json_file")   
    for i in range (len(buff_frame)):
#         print(" ")
        print(hex(buff_frame[i]))
    
    """
    return data_rec
    
    
    
    
    
    
    
    
    
    
    
    
    