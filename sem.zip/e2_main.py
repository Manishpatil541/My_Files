import serial
import time
import json
from pymodbus.client.sync import ModbusSerialClient
from paramater_number import check_in_list
from read_from_xr75 import *
from read_json_file import  *   #read_from_file,function_code_1

from write_to_json_file import *


while 1:
    #read the request from the e2 emsrson
    print(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::")
    data=read_e2_request()
    #ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    #data= ser.read(8)                     #reading the data from the e2 master
#     for i in range (len(data)):           #printing every 8 bytes from the usb buffer
#         print(hex(data[i]))
    #varialbes declaration ::::::::::::::::::::::::::::
    function_counter=data[1]              #function code
    parameter_num_higher_byte=data[2]     #e2 reguested register higher byte
    parameter_num_lower_byte=data[3]      #e2 reguested register lower byte
    #::::::::::::::::::::::::::::::::::::::::::::::::::
    #paramater number caluclation
    parameter_number=(parameter_num_higher_byte << 8 ) | parameter_num_lower_byte   #calculating parameter number 
#     print("e2 requested register number is =",parameter_number)                     #print calculated number 
    
    present=check_in_list(parameter_number)               #this will check the parameter number in the json file and return '1' when found,return '0' when not found
#     print(data,parameter_number)
    if(present == 1): 
        read_from_file(data, parameter_number)             #read data from json file which is alrady in the another therad 
    else :
        print("hand_shaking")
        read_from_xr75(data)                              #the responce is directly send to xr75
    
    print("cycle completer")
       
    