import serial
import time
from pymodbus.client.sync import ModbusSerialClient

def read_e2_request():
    ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
    data= ser.read(6)
    print(data[1])
    if(data[1]==1):
        read_count=8
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
            print(hex(i))
    elif(data[1]==2):
        read_count=8
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
            print(hex(i))
    elif(data[1]==3):
        read_count=8
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
            print(hex(i))
    elif(data[1]==4):
        read_count=8
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
           print(hex(i))
    elif(data[1]==5):
        read_count=8
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
            print(hex(i))
    elif(data[1]==6):
        read_count=8
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
            print(hex(i))
    elif(data[1]==15):
        s1=data[5] // 8
        if(data[5] % 8):
            s1+=1
        read_count=s1+9
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        for i in data:
            print(hex(i))
    elif(data[1]==16):
        read_count=(data[5]*2)+9
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
#         for i in data:
#             print(hex(i))
        
    return data


def read_from_xr75(data):
#     data_1_byte = data[0]
#     data_2_byte = data[1]
#     data_3_byte = data[2]
#     data_4_byte = data[3]
#     data_5_byte = data[4]
#     data_6_byte = data[5]
#     data_7_byte = (data[6])
#     data_8_byte = hex(data[7])
# #     for i in range (8):
    
#         print(hex(data[i]))
    
    #read the request from the e2 emsrson
#     print(":xr75::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::")
#     print("count=",count)
#     count+=1
#     print("new frame request")
#     ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
#     data= ser.read(8) #store the data in data in the form of array
#     data_1_byte = data[0]
#     data_2_byte = data[1]
#     data_3_byte = data[2]
#     data_4_byte = data[3]
#     data_5_byte = data[4]
#     data_6_byte = data[5]
#     data_7_byte = (data[6])
#     data_8_byte = hex(data[7])
#     for i in range (8):
#         print(hex(data[i]))
        
    #print( hex(data_1_byte), hex(data_2_byte), hex(data_3_byte), hex(data_4_byte), hex(data_5_byte), hex(data_6_byte), hex(data_7_byte), data_8_byte)#printing request bytes
    #rite to the slave devce
#     print(data_2_byte)
    comp=data[1]
    if (comp == 1):
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75
         
        s1=data[5]//8
        s2=data[5]%8
        if(s2>0):
            s2=1
        read_num1=s1+s2+5              #calculating the response bytes
#         print(read_num1)              #printing the number ofdata to be recived     
        data_rec=ser.read(read_num1)  #reading the read_count number of bytes from xr75
#         print(data_rec)                #printing the entire resived data
            
        for i in range (read_num1):   #prinitng loop wise
#             print(" ")
            print(hex(data_rec[i]))    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec) 
        
        
        
    elif (3 == data[1]):
        data_rec=0
        if(data[2] == 3 and data[3] == 118 and data[4] == 0 and data[5] == 1):
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data)
            read_count=7
        else:
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data) 
            read_count=((data[5]*2)+5) #calculating the response bytes
         
#         print(read_count)              #printing the number ofdata to be recived     
        data_rec=ser.read(read_count)  #reading the read_count number of bytes from xr75
        #if(data_rec==0):
        #    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        #    ser.write(data)
            
        #    data_rec=ser.read(read_count)
            
#         print(data_rec)                #printing the entire resived data
            
        for i in range (read_count):   #prinitng loop wise
#             print(" ")
            print(hex(data_rec[i]))    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec)  #writing the responce from xr75 is written to e2 emerson
            
    elif (16 == data[1]):
        read_count =((data[5]*2)+9)
#         print("read_count=",read_count)
#         ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
#         data= ser.read(read_count)
#         print("when function code is 10 (hex 16)")
#         print("request from e2")
#         for i in range(11):
#             print(hex(data[i]))
        for i in data:
            print(hex(i))
        
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75       
        
#         print("fc 16 responce will be 8 bytes only ")
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data_rec=ser.read(8)  #reading the read_count number of bytes from xr75
        #print(data_rec)                #printing the entire resived data
#         print("response from xr75")   
        for i in data_rec:   #prinitng loop wise
#             print(" ")
            print(hex(i) )   
    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec)
#             print(data)
           
    elif (comp == 5):
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)
        read_count=8
        
        data_rec=ser.read(read_count)
        for i in data_rec:
#             print(" ")
            print(hex(i))
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec)
#             print(data)

    
    
    
    
    """    
    #print( hex(data_1_byte), hex(data_2_byte), hex(data_3_byte), hex(data_4_byte), hex(data_5_byte), hex(data_6_byte), hex(data_7_byte), data_8_byte)#printing request bytes
    #rite to the slave devce
    print(data_2_byte)
    comp=data_2_byte
    if (comp == 1):
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75
         
        s1=data_6_byte//8
        s2=data_6_byte%8
        if(s2>0):
            s2=1
        read_num1=s1+s2+5              #calculating the response bytes
        print(read_num1)              #printing the number ofdata to be recived     
        data_rec=ser.read(read_num1)  #reading the read_count number of bytes from xr75
        print(data_rec)                #printing the entire resived data
            
        for i in range (read_num1):   #prinitng loop wise
            print(hex(data_rec[i]))    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec) 
        
        
        
    elif (3 == data_2_byte):
        data_rec=0
        if(data_3_byte == 3 and data_4_byte == 118 and data_5_byte == 0 and data_6_byte == 1):
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data)
            read_count=7
        else:
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data) 
            read_count=((data_6_byte*2)+5) #calculating the response bytes
         
        print(read_count)              #printing the number ofdata to be recived     
        data_rec=ser.read(read_count)  #reading the read_count number of bytes from xr75
        #if(data_rec==0):
        #    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        #    ser.write(data)
            
        #    data_rec=ser.read(read_count)
            
        print(data_rec)                #printing the entire resived data
            
        for i in range (read_count):   #prinitng loop wise
            print(hex(data_rec[i]))    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec)  #writing the responce from xr75 is written to e2 emerson
            
    elif (16 == data_2_byte):
        read_count =((data_6_byte*2)+9)
        print("read_count=",read_count)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        print("when function code is 10 (hex 16)")
        print("request from e2")
        for i in range(11):
            print(hex(data[i]))
        
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75       
        
        print("fc 16 responce will be 8 bytes only ")
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data_rec=ser.read(8)  #reading the read_count number of bytes from xr75
        #print(data_rec)                #printing the entire resived data
        print("response from xr75")   
        for i in range (8):   #prinitng loop wise
            print(hex(data_rec[i]))    
    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec)
            print(data)
    """
    
      
def read_again_xr75(data):
    data_1_byte = data[0]
    data_2_byte = data[1]
    data_3_byte = data[2]
    data_4_byte = data[3]
    data_5_byte = data[4]
    data_6_byte = data[5]
    data_7_byte = (data[6])
    data_8_byte = hex(data[7])
    for i in range (8):
        print(" ")
#         print(hex(data[i]))
        
    #print( hex(data_1_byte), hex(data_2_byte), hex(data_3_byte), hex(data_4_byte), hex(data_5_byte), hex(data_6_byte), hex(data_7_byte), data_8_byte)#printing request bytes
    #rite to the slave devce
#     print(data_2_byte)
    comp=data_2_byte
    if (comp == 1):
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75
         
        s1=data_6_byte//8
        s2=data_6_byte%8
        if(s2>0):
            s2=1
        third_byte=s1+s2
        read_num1=s1+s2+5              #calculating the response bytes
#         print(read_num1)              #printing the number ofdata to be recived     
        data_rec=ser.read(read_num1)  #reading the read_count number of bytes from xr75
#         print(data_rec)                #printing the entire resived data
        
        _list_to_return=list(range(0,0))     
#         for i in range (read_num1):   #prinitng loop wise
#             print(hex(data_rec[i]))    
          
        #for i in range (third_byte):
        #_list_to_return.append(data_rec[4])   
        #print("_list_to_return",_list_to_return)
        
        return data_rec[4]
        
       
    elif (3 == data_2_byte):
        data_rec=0
        if(data_3_byte == 3 and data_4_byte == 118 and data_5_byte == 0 and data_6_byte == 1):
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data)
            read_count=7
        else:
            ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            ser.write(data) 
            read_count=((data_6_byte*2)+5) #calculating the response bytes
                      #printing the number ofdata to be recived     
        data_rec=ser.read(read_count)  #reading the read_count number of bytes from xr75
        #if(data_rec==0):
        #    ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        #    ser.write(data)
            
        #    data_rec=ser.read(read_count)
            
#         print(data_rec)                #printing the entire resived data
        return data_rec[4]
            
         #writing the responce from xr75 is written to e2 emerson
    elif(5 == data[1]):
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)
        read_count=8
        time.sleep(0.1) 
        data_rec=ser.read(read_count)
        return data_rec
        
        
        
        
        
        
        
        
        
        
        
        
        
    """        
    elif (16 == data_2_byte):
        read_count =((data_6_byte*2)+9)
        print("read_count=",read_count)
        ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data= ser.read(read_count)
        print("when function code is 10 (hex 16)")
        print("request from e2")
        for i in range(11):
            print(hex(data[i]))
        
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        ser.write(data)                #writing the requested data to xr75       
        
        print("fc 16 responce will be 8 bytes only ")
        ser = serial.Serial('/dev/ttyUSB0', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
        data_rec=ser.read(8)  #reading the read_count number of bytes from xr75
        #print(data_rec)                #printing the entire resived data
        print("response from xr75")   
        for i in range (8):   #prinitng loop wise
            print(hex(data_rec[i]))    
    
        if data_rec:
            ser = serial.Serial('/dev/ttyUSB1', baudrate=9600, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE)
            data= ser.write(data_rec)
            print(data)
    """