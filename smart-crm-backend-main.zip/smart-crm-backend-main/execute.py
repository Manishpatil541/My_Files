import os

os.system("cd E:\\Office\\CRM\\smart-crm-backend & e: & conda activate crm & python manage.py runserver")