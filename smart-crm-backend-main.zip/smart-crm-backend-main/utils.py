from django.conf import settings


def get_host_email():
    """Utility function to get host email 

    if already set in settings
    else return smartcrm@smartenovations.com
    """

    return getattr(settings, 'EMAIL_HOST_USER', 'smartcrm@smartenovations.com')
