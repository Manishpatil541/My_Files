from apps.customer.serializers.customer import CustomerImportSerializer
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.utils.encoding import force_text
from django.utils import timezone
from django.db.models import Count, Q
from django.db.models.fields import NOT_PROVIDED
from django.core.files.uploadedfile import InMemoryUploadedFile

from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import DjangoModelPermissions
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.decorators import api_view, permission_classes

import datetime
import pandas as pd

from .constants import *
from .models import Category, Customer, Industry, CustomerContact
from .models import StageP2, StageP3, StageP4, StageP5
from .models import PlanAhead
from .models import CustomerNote
from .serializers import (CustomerSerializer, CustomerContactSerializer,
                          IndustrySerializer, CategorySerializer,
                          CountryCountSerializer)
from .serializers import StageP2Serializer, StageP3Serializer, StageP4Serializer, StageP5Serializer
from .serializers import PlanAheadSerializer
from .serializers import CustomerNoteSerializer
from .signals import outcome_change_signal
from .permissions import CanApproveProspect
from .utils import CustomerImporter, ImportResult


customer_importer = CustomerImporter()


class CustomerViewSet(viewsets.ModelViewSet):

    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

    permission_classes = [DjangoModelPermissions, ]

    ordering_fields = ['created_on', 'modified_on']
    filterset_fields = {
        'modified_on': ['lte'],
        'outcome': ['exact'],
        'confirmed_addition': ['exact']
    }

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user,
                        assigned_to=self.request.user)

    def options(self, request, *args, **kwargs):

        meta = self.metadata_class()
        data = meta.determine_metadata(request, self)
        data['default'] = {field.name: force_text(
            ''
            if (getattr(field, 'default', None) == NOT_PROVIDED)
            else getattr(field, 'default', None),
            strings_only=True)
            for field in Customer._meta.get_fields()}

        return Response(data)

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return Customer.objects.all()
        elif user.groups.name == 'Manager':
            return Customer.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return Customer.objects.filter(assigned_to=user)


class CustomerContactViewSet(viewsets.ModelViewSet):

    queryset = CustomerContact.objects.all()
    serializer_class = CustomerContactSerializer
    filterset_fields = ['customer']

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return CustomerContact.objects.all()
        elif user.groups.name == 'Manager':
            return CustomerContact.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return CustomerContact.objects.filter(users=user)


@api_view(['GET'])
def customer_won_count_datewise(request):

    data = Customer.objects.filter(outcome="Won").values(
        'outcome_date').annotate(customers=Count('id')).order_by('outcome_date')

    user = request.user

    if user.groups.name == 'Manager':
        data = data.filter(
            Q(created_by=user) |
            Q(created_by__reports_to=user)
        )
    elif user.groups.name == 'BDE':
        data = data.filter(created_by=user)

    return Response(data)


class CustomerNoteViewSet(viewsets.ModelViewSet):

    queryset = CustomerNote.objects.all()
    serializer_class = CustomerNoteSerializer

    filterset_fields = {
        'customer': ['exact'],
        'remind_on': ['date'],
        'is_reminder': ['exact']
    }

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    def get_queryset(self):
        user = self.request.user

        return CustomerNote.objects.filter(user=user)


class IndustryViewSet(viewsets.ModelViewSet):

    queryset = Industry.objects.all()
    serializer_class = IndustrySerializer


class CategoryViewSet(viewsets.ModelViewSet):

    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class StageP2ViewSet(viewsets.ModelViewSet):

    queryset = StageP2.objects.all()
    serializer_class = StageP2Serializer


class StageP3ViewSet(viewsets.ModelViewSet):

    queryset = StageP3.objects.all()
    serializer_class = StageP3Serializer


class StageP4ViewSet(viewsets.ModelViewSet):

    queryset = StageP4.objects.all()
    serializer_class = StageP4Serializer


class StageP5ViewSet(viewsets.ModelViewSet):

    queryset = StageP5.objects.all()
    serializer_class = StageP5Serializer


class PlanAheadViewSet(viewsets.ModelViewSet):

    queryset = PlanAhead.objects.all()
    serializer_class = PlanAheadSerializer

    filterset_fields = ['company_name__industry',
                        'company_name__country', 'completed']

    def perform_create(self, serializer):
        today = timezone.now().date()
        serializer.save(created_by=self.request.user, plan_ahead_types={
                        "log": [{"date": str(today), "value": "Added to Plan"}, {"date": str(today), "value": "Yet to Start"}]})


@api_view(['GET'])
def plan_ahead_within_dates(request):
    new_format = "%a %b %d %Y %H:%M:%S"  # format of prime react calendar

    start_range, _ = request.GET.get('start_date').split(" GMT")
    start_range = datetime.datetime.strptime(
        start_range, new_format)
    end_range, _ = request.GET.get('end_date').split(" GMT")
    end_range = datetime.datetime.strptime(
        end_range, new_format)
    end_range = end_range.replace(hour=23, minute=59, second=59)

    plans = PlanAhead.objects.filter(
        created_on__range=[start_range, end_range])
    serailized_plans = PlanAheadSerializer(plans, many=True)

    return Response(serailized_plans.data)


@api_view(['GET'])
def stage_count_view(request):

    user = request.user

    customer = Customer.objects.all()

    if user.groups.name in ['CEO', 'Admin']:
        pass
    elif user.groups.name == 'Manager':
        customer = customer.filter(
            Q(created_by=user) |
            Q(created_by__reports_to=user)
        )
    else:
        customer = customer.filter(Q(created_by=user) | Q(assigned_to=user))

    data = {
        'stagep1': [c for c in customer if c.current_stage == STAGE_P1].__len__(),
        'stagep2': [c for c in customer if c.current_stage == STAGE_P2].__len__(),
        'stagep3': [c for c in customer if c.current_stage == STAGE_P3].__len__(),
        'stagep4': [c for c in customer if c.current_stage == STAGE_P4].__len__(),
        'stagep5': [c for c in customer if c.current_stage == STAGE_P5].__len__(),
    }

    return Response(data)


@api_view(['GET'])
def country_count_view(request):

    data = Customer.objects.values('country').annotate(Count('country'))
    serializer = CountryCountSerializer(data, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def accept_stage_view(request, stage_number, stage_id):

    model = globals()[f'StageP{stage_number}']

    obj: StageP2 = get_object_or_404(model, id=stage_id)
    obj.accept_stage()

    return Response("Accepted")


@api_view(['POST'])
def update_customer_outcome(request, customer_id):

    customer = get_object_or_404(Customer, id=customer_id)

    outcome = request.data['outcome']
    outcome_date = request.data['outcome_date']
    remarks = request.data['remarks']

    customer.outcome = outcome
    customer.outcome_date = outcome_date
    customer.remarks = remarks
    customer.save()

    # trigger signal
    outcome_change_signal.send(sender=Customer, instance=customer)

    return Response()


@api_view(['GET'])
def similar_customer(request, customer_id):

    customer = get_object_or_404(Customer, id=customer_id)

    data = Customer.objects.filter(
        customer__iexact=customer.customer,
        country=customer.country,
        location__iexact=customer.location
    ).exclude(id=customer.id)
    serializer = CustomerSerializer(data, many=True)
    return Response(serializer.data)


@api_view(['GET'])
# only user with can_approve_prospect can approve
@permission_classes([CanApproveProspect])
def confirm_prospect_addition(request, customer_id):

    customer = get_object_or_404(Customer, id=customer_id)

    customer.confirm_customer_addition()

    return Response()


@api_view(['GET'])
@permission_classes([CanApproveProspect])
def reject_prospect_addition(request, customer_id):

    customer = get_object_or_404(Customer, id=customer_id)

    customer.reject_customer_approval()

    return Response()


def customer_import_template_view(request):

    # create httpresponse object with content_type
    response = HttpResponse(content_type='application/xlsx')
    response['Content-Disposition'] = 'attachment; filename="customer-import-template.xlsx"'

    data = customer_importer.get_template()

    # write binary data to the response
    response.write(data)

    return response


class CustomerImportViewSet(APIView):

    serializer_class = CustomerImportSerializer
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):

        serializer = CustomerImportSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            file: InMemoryUploadedFile = serializer.validated_data['file']

            if file.name.endswith('.csv'):
                df = pd.read_csv(file, dtype=str)
            else:
                df = pd.read_excel(file, dtype=str)

            result = customer_importer.process_upload(df)

            if not result.success:
                return Response(result.message, status=400)

            return Response(result.data)

        except:
            # if everthing goes wrong
            # especially different file format like images
            return Response('Please upload a supported file', status=400)
