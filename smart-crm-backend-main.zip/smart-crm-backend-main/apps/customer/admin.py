from django.contrib import admin
from .models import *


class NoteInline(admin.StackedInline):
    model = CustomerNote
    extra = 1


class CustomerAdmin(admin.ModelAdmin):

    model = Customer
    inlines = [
        NoteInline
    ]


admin.site.register(Category)
admin.site.register(Industry)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(CustomerContact)

admin.site.register(StageP2)
admin.site.register(StageP3)
admin.site.register(StageP4)
admin.site.register(StageP5)

admin.site.register(PlanAhead)
admin.site.register(CustomerNote)
