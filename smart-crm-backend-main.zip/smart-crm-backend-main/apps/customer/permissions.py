from rest_framework.permissions import BasePermission, IsAuthenticated, SAFE_METHODS


class CanApproveProspect(BasePermission):
    """Return True if the user have permission to approve prospect"""

    def has_permission(self, request, view):

        return request.user.has_perm('customer.can_approve_prospect')
