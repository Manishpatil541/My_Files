from django.db.models import Q
from rest_framework import serializers

from django_countries import countries
from django_countries.serializer_fields import CountryField

from ..models import Customer, CustomerContact


class CustomerSerializerField(serializers.PrimaryKeyRelatedField):
    def get_queryset(self):
        user = self.context['request'].user

        if user.groups.name in ['CEO', 'Admin', 'Finance']:
            return Customer.objects.all()
        elif user.groups.name == 'Manager':
            return Customer.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        return Customer.objects.filter(created_by=user)


class CustomerSerializer(serializers.ModelSerializer):

    industry_name = serializers.ReadOnlyField(source='industry.industry')

    country_name = serializers.ReadOnlyField(source='country.name')
    country_alpha3 = serializers.ReadOnlyField(source='country.alpha3')

    stagep2 = serializers.ReadOnlyField(source='stagep2.id')
    stagep3 = serializers.ReadOnlyField(source='stagep3.id')
    stagep4 = serializers.ReadOnlyField(source='stagep4.id')
    stagep5 = serializers.ReadOnlyField(source='stagep5.id')

    confirmed_addition = serializers.ReadOnlyField()

    created_by_email = serializers.ReadOnlyField(source='created_by.email')
    assigned_to_email = serializers.ReadOnlyField(source='assigned_to.email')

    class Meta:
        model = Customer
        fields = ['id', 'customer',
                  'country', 'country_name', 'country_alpha3', 'location',
                  'outcome', 'outcome_date', 'remarks',
                  'contact_person', 'contact_number', 'contact_email',
                  'industry', 'industry_name', 'website',
                  'about', 'is_india', 'is_lcr',
                  'area_of_specialization', 'comments',
                  'current_stage',
                  'stagep2', 'stagep3', 'stagep4', 'stagep5',
                  'created_by', 'assigned_to',
                  'created_by_email', 'assigned_to_email',
                  'created_on', 'modified_on',
                  'confirmed_addition']

        read_only_fields = ['outcome', 'outcome_date', 'remarks']


class CountryCountSerializer(serializers.Serializer):

    country = CountryField()
    country__name = serializers.SerializerMethodField()
    country__alpha3 = serializers.SerializerMethodField()
    country__count = serializers.IntegerField()
    customers = serializers.SerializerMethodField()

    def get_customers(self, obj):
        serializer = CustomerSerializer(
            Customer.objects.filter(country=obj['country']), many=True)
        return serializer.data

    def get_country__alpha3(self, obj):
        return countries.alpha3(obj['country'])

    def get_country__name(self, obj):
        return countries.name(obj['country'])


class CustomerContactSerializer(serializers.ModelSerializer):

    country_name = serializers.ReadOnlyField(source='country.name')

    class Meta:
        model = CustomerContact
        fields = ['id', 'customer', 'contact_name', 'designation', 'email',
                  'phone', 'location', 'country', 'created_by', 'users',
                  'country_name']


class CustomerImportSerializer(serializers.Serializer):

    file = serializers.FileField()
