from rest_framework import serializers

from ..models import PlanAhead


class PlanAheadSerializer(serializers.ModelSerializer):
    industry = serializers.ReadOnlyField(
        source='company_name.industry.industry')
    country = serializers.ReadOnlyField(source='company_name.country.name')
    customer_name = serializers.ReadOnlyField(source="company_name.customer")

    class Meta:
        model = PlanAhead
        fields = ['company_name', 'customer_name', 'expiry_week', 'created_on', 'modified_on',
                  'plan_ahead_types', 'completed', 'industry', 'country', 'created_by']
