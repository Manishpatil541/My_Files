from rest_framework import serializers

from ..models import StageP2, StageP3, StageP4, StageP5


class StageP2Serializer(serializers.ModelSerializer):
    class Meta:
        model = StageP2
        fields = '__all__'


class StageP3Serializer(serializers.ModelSerializer):
    class Meta:
        model = StageP3
        fields = '__all__'


class StageP4Serializer(serializers.ModelSerializer):
    class Meta:
        model = StageP4
        fields = '__all__'


class StageP5Serializer(serializers.ModelSerializer):
    class Meta:
        model = StageP5
        fields = '__all__'
