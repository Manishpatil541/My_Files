from django.contrib.contenttypes.models import ContentType
from rest_framework import serializers

from ..models import CustomerNote


class CustomerNoteSerializer(serializers.ModelSerializer):

    customer_name = serializers.ReadOnlyField(source='customer.customer')
    user_email = serializers.ReadOnlyField(source='user.email')

    class Meta:
        model = CustomerNote
        fields = ['id', 'message', 'is_reminder', 'reminded', 'customer',
                  'remind_on', 'user', 'created_on', 'customer_name', 'user_email']
