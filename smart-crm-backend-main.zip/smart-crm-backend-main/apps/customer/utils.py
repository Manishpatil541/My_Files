from collections import namedtuple
import urllib.parse as url_parse
import pandas as pd

from io import BytesIO
from xlsxwriter import Workbook
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
from django_countries import countries

from rest_framework.serializers import ModelSerializer, Serializer

from .serializers import CustomerSerializer
from .models import Industry


class ImportData():

    def __init__(self, serializer: ModelSerializer, exclude=[]):

        self.serializer = serializer
        self.exclude = exclude

        self.workbook_bytes = BytesIO()
        self.workbook = Workbook(self.workbook_bytes)
        self.worksheet = self.workbook.add_worksheet()
        self.template = b''

        self.required_fields: dict = {}
        self.other_fields: dict = {}
        self.all_fields: dict = {}

        self._gen_template()
        self._close_xlsx()

    def _gen_template(self):

        _fields: dict = self.serializer().get_fields()

        _fields = {n: f for n, f in _fields.items() if n not in self.exclude}

        self.required_fields = {n: f
                                for n, f in _fields.items() if f.required}

        self.other_fields = {n: f for n, f in _fields.items()
                             if not f.required and not f.read_only}
        self.all_fields = self.required_fields | self.other_fields

        row, col = 0, 0
        for name, field in self.required_fields.items():
            self.worksheet.write(row, col, name + '*')
            col += 1

        for name, field in self.other_fields.items():
            self.worksheet.write(row, col, name)
            col += 1

        # change width of columns
        self.worksheet.set_column(0, len(self.all_fields), 15)

    def _close_xlsx(self):

        self.workbook.close()
        self.template = self.workbook_bytes.getvalue()

    def get_template(self):

        return self.template

    def _check_eligible_to_import(self, df: pd.DataFrame):
        """Data should not have columns other than columns in all_field"""

        return set(df.columns).issubset(self.all_fields.keys())


ImportResult = namedtuple('ImportResult', ['success', 'data', 'message'])


class CustomerImporter(ImportData):

    def __init__(self):
        super().__init__(CustomerSerializer, exclude=[
            'is_india', 'is_lcr', 'current_stage', 'created_by', 'assigned_to'])

        self.industry_choices = []
        self.country_choices = [
            v for k, v in self.all_fields['country'].choices.items()]

    def _refetch_industry_choices(self):
        self.industry_choices = [
            v for k, v in self.all_fields['industry'].choices.items()]

    def _process_industry_field(self, value: str):
        """Find a close match, if not found create field and return id"""

        if not value:
            return value

        value = value.capitalize()

        (match, ratio) = process.extractOne(
            value, self.industry_choices, scorer=fuzz.ratio)

        if ratio > 60:
            industry = Industry.objects.get(industry=match)
        else:
            industry = Industry.objects.create(industry=value)

        return industry.id

    def _process_country_field(self, value):
        """Find a close match of country and return the value"""

        if not value:
            return value

        value = value.capitalize()

        (match, ratio) = process.extractOne(
            value, self.country_choices, scorer=fuzz.ratio)

        if ratio > 60:
            country = countries.by_name(match)

        return country

    def _process_website_field(self, url: str):

        if not url:
            return url

        _split_url = url_parse.urlsplit(url)

        _url = url_parse.SplitResult(
            scheme=_split_url.scheme if _split_url.scheme else 'https',
            netloc=_split_url.netloc if _split_url.netloc else _split_url.path,
            path='',
            query='',
            fragment=''
        )

        return url_parse.urlunsplit(_url)

    def process_upload(self, df: pd.DataFrame):

        if df.empty:
            # empty dataframe
            return ImportResult(success=False, data=None, message="Empty excel sheet")

        if df.duplicated().any():
            return ImportResult(success=False, data=None, message="Duplicate rows present")

        # fill NaN cells to empty string
        df = df.fillna('')

        # refetch latest industry choice list
        self._refetch_industry_choices()

        # remove * in column names
        df.columns = df.columns.str.strip('*')

        if not self._check_eligible_to_import(df):
            return ImportResult(success=False, data=None, message="Please provide excel based on template file")

        # initialize response data
        response_data = []

        for i in df.index:
            data = {}
            parsed_data = {}
            for col in df.columns:

                value = df.loc[i][col]

                # store the original data
                data[col] = value

                # process industry
                if col == 'industry':
                    value = self._process_industry_field(value)

                # process country
                if col == 'country':
                    value = self._process_country_field(value)

                # process website
                if col == 'website':
                    value = self._process_website_field(value)

                # store parsed data
                parsed_data[col] = value

            # process data with serializer
            s_data: Serializer = self.serializer(data=parsed_data)

            # run validation
            valid = s_data.is_valid()

            # add in correct data
            response_data.append({
                'data': data,
                'parsed_data': parsed_data,
                'has_error': not valid,
                'errors': s_data.errors
            })

        # return response_data
        return ImportResult(success=True, data=response_data, message="Your data have been parsed")
