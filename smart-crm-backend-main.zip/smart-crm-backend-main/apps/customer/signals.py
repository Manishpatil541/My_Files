from datetime import datetime
from django.db.models.signals import post_save
from django.utils import timezone
from django.dispatch import Signal, receiver

from .models import Customer


stage_accepted_signal = Signal()
outcome_change_signal = Signal()
customer_approval_request = Signal()


@receiver(post_save, sender='customer.Customer')
def is_customer_eligible(sender, instance: Customer, created, *arg, **kwargs):

    if created:
        customer = instance

        customer_name = getattr(customer, 'customer')
        country = getattr(customer, 'country')
        location = getattr(customer, 'location')

        time_threshold = timezone.now() - timezone.timedelta(days=6*30)

        customers_present = Customer.objects.filter(
            customer__iexact=customer_name,
            modified_on__gt=time_threshold,
            country=country,
            location__iexact=location
        ).exclude(id=customer.id)

        # filter customer (based on inquiry and customer po, events)
        if len(customers_present) > 0:
            instance.confirmed_addition = False
            instance.outcome = instance.OutcomeTypes.WAITING_FOR_APPROVAL
            instance.outcome_date = datetime.now().date()
            instance.save()

            # send for approval
            customer_approval_request.send(None,
                                           new_customer=instance, existing_customers=customers_present)
