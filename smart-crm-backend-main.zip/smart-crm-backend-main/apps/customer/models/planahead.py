from django.db import models
from django.db.models import Q
from django.contrib.admin.models import LogEntry
from django.contrib.auth import get_user_model

from .customer import Customer

# instantiate User
User = get_user_model()


class PlanAhead(models.Model):

    company_name = models.OneToOneField(
        Customer, limit_choices_to=Q(outcome=Customer.OutcomeTypes.WON), primary_key=True, on_delete=models.CASCADE)
    expiry_week = models.DateField()
    plan_ahead_types = models.JSONField(null=True)

    created_by = models.ForeignKey(User, null=True, blank=True,
                                   on_delete=models.RESTRICT,
                                   related_name='plan_ahead_created_by')
    completed = models.BooleanField(default=False)
    created_on = models.DateTimeField(auto_now=False, auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True, auto_now_add=False)

    def __str__(self):
        return str(self.company_name)

    def get_emails(self):
        """Returns only the email of created by user"""

        emails = []

        if self.created_by:
            emails.append(self.created_by.email)

        return set(emails)
