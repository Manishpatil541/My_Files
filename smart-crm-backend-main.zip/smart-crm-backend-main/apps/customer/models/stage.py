from django.db import models
from django.contrib.auth import get_user_model
from django.utils.timezone import now

from .category import Category
from .customer import Customer
from ..signals import stage_accepted_signal


User = get_user_model()


class Stage(models.Model):
    # https://docs.djangoproject.com/en/3.2/topics/db/models/#abstract-base-classes
    customer = models.OneToOneField(
        Customer, related_name='%(class)s', on_delete=models.CASCADE)

    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

    stage_accepted = models.BooleanField(default=False)
    stage_accepted_date = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        '''Update project model on any change in stage'''

        instance = super(Stage, self).save(*args, **kwargs)
        self.customer.save()
        return instance

    def accept_stage(self):
        if self.stage_accepted:
            return
        self.stage_accepted = True
        self.stage_accepted_date = now()
        self.save()

        # signal
        stage_accepted_signal.send(sender=self)

    @classmethod
    def get_class_name(cls):
        return cls.__name__

    def __str__(self):
        return f'{self.customer.customer} {self.get_class_name()}'


class StageP2(Stage):
    requirement = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.RESTRICT)

    # decision makers
    # technical
    td_name = models.CharField(
        'Technical Decision Maker Name', max_length=250, null=True, blank=True)
    td_phone = models.CharField(
        'Technical Decision Maker Phone', null=True, blank=True, max_length=20)
    td_email = models.EmailField(
        'Technical Decision Maker Email', null=True, blank=True)

    # financial
    fd_name = models.CharField(
        'Financial Decision Maker Name', max_length=250, null=True, blank=True)
    fd_phone = models.CharField(
        'Financial Decision Maker Phone', null=True, blank=True, max_length=20)
    fd_email = models.EmailField(
        'Financial Decision Maker Email', null=True, blank=True)

    project_brief = models.TextField()
    expected_next_stage_date = models.DateField(null=True, blank=True)


class StageP3(Stage):
    is_nda_completed = models.BooleanField(
        'NDA Sign off Completed', default=False)
    is_inquiry_rfq_created = models.BooleanField(
        'Inquiry/RFQ Created', default=False)
    is_pilots_completed = models.BooleanField(
        'Pilots completed', default=False)

    # TODO: inquiry


class StageP4(Stage):
    is_technical_proposal_accepted = models.BooleanField(
        'Technical proposal accepted', default=False)

    type_of_service = models.CharField(max_length=250, null=True, blank=True)
    confidence_level = models.IntegerField('Confidence level (in %)')

    # TODO: opportunity

    approx_profit_margin = models.IntegerField()

    identified_onsite_offshore = models.BooleanField(
        'Identified onsite/offshore', default=False)


class StageP5(Stage):
    is_commercial_negotiations_completed = models.BooleanField(
        'Commercial negotiations completed', default=False)
    commercial_negotiations_acceptance_date = models.DateField(
        'Commercial Negotiations acceptance date', null=True, blank=True)

    is_tech_commercial_proposals_submitted = models.BooleanField(
        'Technical commercial proposals submitted', default=False)
    tech_commercial_proposals_submitted_date = models.DateField(
        'Tech Commercial proposals submitted date', null=True, blank=True)

    is_drafted_contract_agreement = models.BooleanField(
        'Draft of Contract/Agreement', default=False)
    contract_agreement_validated_date = models.DateField(
        'Draft Contract validated date', null=True, blank=True)

    is_waiting_for_po = models.BooleanField('Waiting for PO', default=False)
    po_expected_date = models.DateField(
        'PO expected date', null=True, blank=True)

    confidence_level = models.IntegerField(
        'Confidence level (in %)', null=True, blank=True)
