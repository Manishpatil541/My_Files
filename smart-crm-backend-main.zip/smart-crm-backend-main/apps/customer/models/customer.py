from django.contrib.auth import get_user_model
from django.db import models
from django.db.models import Q

from django_countries.fields import CountryField

from datetime import datetime

from .industry import Industry


# instantiate User
User = get_user_model()


class CURRENT_STAGE(models.TextChoices):

    Stage_P1 = "Stage P1"
    Stage_P2 = "Stage P2"
    Stage_P3 = "Stage P3"
    Stage_P4 = "Stage P4"
    Stage_P5 = "Stage P5"
    Waiting_for_approval = "Waiting for approval"


class Customer(models.Model):

    class OutcomeTypes(models.TextChoices):

        LOSS = 'Loss'
        WON = 'Won'
        DROP = 'Drop'
        PROSPECT = 'Prospect'
        WAITING_FOR_APPROVAL = 'Waiting for Approval'
        REJECTED = 'Rejected'

    customer = models.CharField(max_length=250)
    country = CountryField()
    location = models.CharField(max_length=500)

    # contact information
    contact_email = models.EmailField()
    contact_number = models.CharField(max_length=20, null=True, blank=True)
    contact_person = models.CharField(max_length=250)

    industry = models.ForeignKey(
        Industry, on_delete=models.RESTRICT)
    website = models.URLField()

    about = models.TextField(null=True, blank=True)

    is_india = models.BooleanField('is India', default=False)
    is_lcr = models.BooleanField('is LCR', default=False)

    area_of_specialization = models.TextField(null=True, blank=True)

    comments = models.TextField(null=True, blank=True)

    created_by = models.ForeignKey(User, null=True, blank=True,
                                   on_delete=models.RESTRICT,
                                   related_name='created')

    assigned_to = models.ForeignKey(User, null=True, blank=True,
                                    on_delete=models.RESTRICT,
                                    related_name='assigned')

    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

    outcome = models.CharField(
        max_length=25, choices=OutcomeTypes.choices, default=OutcomeTypes.PROSPECT)
    outcome_date = models.DateField(blank=True, null=True)

    # remark on outcome change
    remarks = models.TextField(default='', blank=True)

    confirmed_addition = models.BooleanField(default=True)

    current_stage = models.CharField(
        max_length=25, default=CURRENT_STAGE.Stage_P1, choices=CURRENT_STAGE.choices)

    def __str__(self):
        return self.customer

    def get_current_stage(self):
        stage = 2

        if not self.confirmed_addition:
            return CURRENT_STAGE.Waiting_for_approval

        while True:
            if not self.has_stage(f'stagep{stage}'):
                stage -= 1
                break
            else:
                if not getattr(self, f'stagep{stage}').stage_accepted:
                    stage -= 1
                    break

            stage += 1

        return f'Stage P{stage}'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not (self.current_stage == self.get_current_stage()):
            self.current_stage = self.get_current_stage()
            self.save()

    def has_stage(self, stage):
        return hasattr(self, stage)

    def get_user_emails(self):
        '''Return all user email associated with this customer'''

        user_emails = []

        # using walrus operator
        # if u := self.assigned_to:
        #     user_emails.append(u.email)
        # if u := self.created_by:
        #     user_emails.append(u.email)

        if self.assigned_to:
            user_emails.append(self.assigned_to.email)
            if self.assigned_to.reports_to:
                user_emails.append(self.assigned_to.reports_to.email)
        if self.created_by:
            user_emails.append(self.created_by.email)
            if self.created_by.reports_to:
                user_emails.append(self.created_by.reports_to.email)

        return set(user_emails)

    @classmethod
    def search(cls, user, term):

        queryset = None

        # filter based on user
        if user.groups.name in ['CEO', 'Admin']:
            queryset = Customer.objects.all()
        elif user.groups.name == 'Manager':
            queryset = Customer.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            queryset = Customer.objects.filter(created_by=user)

        customer_list = ["customer", "contact_number", "contact_person", "industry__industry", "website", "about", "is_india",
                         "is_lcr", "area_of_specialization", "comments", "created_on", "modified_on", "outcome", "outcome_date", "remarks"]

        query = Q()
        for customer in customer_list:
            customer += '__icontains'
            query.add(Q(**{customer: term}), Q.OR)

        result = queryset.filter(query)
        return result

    def confirm_customer_addition(self):

        self.confirmed_addition = True
        self.outcome = self.OutcomeTypes.PROSPECT
        self.outcome_date = datetime.now().date()

        self.save()

    def reject_customer_approval(self):

        self.confirmed_addition = False
        self.outcome = self.OutcomeTypes.REJECTED
        self.outcome_date = datetime.now().date()

        self.save()

    class Meta:
        ordering = ['-modified_on']
        permissions = (
            ("can_approve_prospect", "Can approve prospect"),
        )


class CustomerContact(models.Model):

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    contact_name = models.CharField(max_length=250)
    designation = models.CharField(max_length=250, default='', blank=True)

    email = models.EmailField()
    phone = models.CharField(max_length=20, null=True, blank=True)

    location = models.CharField(max_length=250)
    country = CountryField()

    created_by = models.ForeignKey(
        'login.User', null=True, blank=True, on_delete=models.CASCADE)

    users = models.ManyToManyField(
        'login.User', related_name='contacts', blank=True)
