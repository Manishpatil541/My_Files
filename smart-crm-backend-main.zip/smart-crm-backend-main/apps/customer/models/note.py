from django.db import models

from .customer import Customer
from apps.common.models import Note


class CustomerNote(Note):

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
