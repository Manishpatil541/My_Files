from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import CustomerImportViewSet, CustomerViewSet, CategoryViewSet, IndustryViewSet, CustomerContactViewSet
from .views import customer_won_count_datewise
from .views import StageP2ViewSet, StageP3ViewSet, StageP4ViewSet, StageP5ViewSet
from .views import PlanAheadViewSet
from .views import stage_count_view, country_count_view, accept_stage_view
from .views import update_customer_outcome, confirm_prospect_addition, similar_customer
from .views import reject_prospect_addition
from .views import plan_ahead_within_dates
from .views import customer_import_template_view
from .views import CustomerNoteViewSet

app_name = 'customer'

router = DefaultRouter()
router.register(r'customer', CustomerViewSet)
router.register(r'customer-contact', CustomerContactViewSet)
router.register(r'customer-notes', CustomerNoteViewSet,
                basename='customer-notes')
router.register(r'customer-contact', CustomerContactViewSet)
router.register(r'category', CategoryViewSet)
router.register(r'industry', IndustryViewSet)
router.register(r'stagep2', StageP2ViewSet, basename='stagep2')
router.register(r'stagep3', StageP3ViewSet, basename='stagep3')
router.register(r'stagep4', StageP4ViewSet, basename='stagep4')
router.register(r'stagep5', StageP5ViewSet, basename='stagep5')
router.register(r'planahead', PlanAheadViewSet, basename='planahead')

urlpatterns = [
    path('', include(router.urls)),
    path('stage-count', stage_count_view),
    path('country-count', country_count_view),
    path('accept-stage/<int:stage_number>/<int:stage_id>', accept_stage_view),
    path('update-outcome/<int:customer_id>/', update_customer_outcome),
    path('similar-customer/<int:customer_id>', similar_customer),
    path('confirm-prospect-addition/<int:customer_id>',
         confirm_prospect_addition, name='confirm-customer'),
    path('reject-prospect-addition/<int:customer_id>',
         reject_prospect_addition, name='reject-customer'),
    path('plans-within-date/', plan_ahead_within_dates, name='plans-within-date'),
    path('customer-import/template', customer_import_template_view),
    path('customer-import/', CustomerImportViewSet.as_view()),
    path('datewise-count/', customer_won_count_datewise),
]
