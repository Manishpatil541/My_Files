from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import EmailMessage

from apps.customer.signals import stage_accepted_signal, outcome_change_signal
from utils import get_host_email

from .models import Notification


host_email = get_host_email()


@receiver(stage_accepted_signal)
def on_stage_accepted(sender, **kwargs):
    # sender is the statge instance

    # create message from sender (Stage Model) data
    message = f'{sender.__class__.__name__} have been accepted for {sender.customer.customer}'

    # create a notification and save
    m = Notification.objects.create(
        message=message, user=sender.customer.created_by)
    m.save()

    # send mail
    user_mails = sender.customer.get_user_emails()
    email = EmailMessage(
        f'Stage accepted for {sender.customer.customer}',
        message,
        host_email,
        user_mails or ['admin@smartcrm.com'],
    )
    email.send(fail_silently=True)


@receiver(post_save, sender='customer.Customer')
def on_customer_creation(sender, instance, created, *arg, **kwargs):

    if created:
        message = f'New Customer {instance.customer} have been created'

        m = Notification.objects.create(
            message=message, user=instance.created_by)
        m.save()


def on_stage_creation(sender, instance, created, *arg, **kwargs):

    if created:
        message = f'{instance.__class__.__name__} have been created for {instance.customer.customer}'

        m = Notification.objects.create(
            message=message, user=instance.customer.created_by)
        m.save()


post_save.connect(on_stage_creation, sender='customer.StageP2')
post_save.connect(on_stage_creation, sender='customer.StageP3')
post_save.connect(on_stage_creation, sender='customer.StageP4')
post_save.connect(on_stage_creation, sender='customer.StageP5')


@receiver(post_save, sender='events.Event')
def on_event_creation(sender, instance, created, *arg, **kwargs):

    if created:
        message = f'Event have been created for {instance.customer_name} schedule on {instance.start_date} at {instance.start_time}'

        m = Notification.objects.create(
            message=message, user=instance.created_by)
        m.save()


@receiver(post_save, sender='inquiry.Newinquiry')
def on_inquiry_creation(sender, instance, created, *arg, **kwargs):

    if created:
        message = f' New Inquiry have been created for {instance.customername}'

        n = Notification.objects.create(
            message=message, user=instance.created_by)
        n.save()


@receiver(outcome_change_signal)
def on_outcome_change(instance, *args, **kwargs):

    message = f'Outcome have been changes for {instance.customer} to {instance.outcome}'

    # create notification
    n = Notification.objects.create(message=message, user=instance.created_by)
    n.save()


@receiver(post_save, sender='customer.PlanAhead')
def on_planahead_creation(sender, instance, created, *args, **kwargs):

    if created:
        message = f"{instance.company_name.customer} has been added in the plan ahead"

        # creating notification
        nt = Notification.objects.create(
            message=message, user=instance.created_by)
        nt.save()

        # send mail when the plan is created
        user_mail = sender.get_emails(instance)
        email = EmailMessage(
            f'Created plan Ahead for {instance.company_name.customer}',
            message,
            host_email,
            user_mail,
        )
        email.send(fail_silently=True)


@receiver(post_save, sender='customer.PlanAhead')
def on_planahead_complete(sender, instance, *args, **kwargs):
    # notifictation only iff it is comlpleted

    if instance.completed:
        msg = f"{instance.company_name.customer} has been completed"

        notify = Notification.objects.create(
            message=msg, user=instance.created_by)
        notify.save()

        # send mail when the plan is completed iff manager created the plan
        user_mail = sender.get_emails(instance)
        email = EmailMessage(
            f'Completed plan Ahead for {instance.company_name.customer}',
            msg,
            host_email,
            user_mail,  # add the manager mail id
        )
        email.send(fail_silently=True)

        # TODO create the plan ahead to assign it to the bde
