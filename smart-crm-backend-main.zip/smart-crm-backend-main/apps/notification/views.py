from rest_framework.viewsets import ReadOnlyModelViewSet
from django.db.models import Q

from .models import Notification
from .serializers import NotificationSerializer


class NotificationViewSet(ReadOnlyModelViewSet):

    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return Notification.objects.all()
        elif user.groups.name == 'Manager':
            return Notification.objects.filter(
                Q(user=user) |
                Q(user__reports_to=user)
            )
        else:
            return Notification.objects.filter(user=user)
