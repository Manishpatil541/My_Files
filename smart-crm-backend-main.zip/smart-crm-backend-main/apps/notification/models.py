from django.db import models
from django.contrib.auth import get_user_model


User = get_user_model()


class Notification(models.Model):

    message = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    class Meta:
        ordering = ['-created_on']
