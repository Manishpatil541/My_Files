from django.db.models import Q
from django.shortcuts import render
from django.db.models import Count, F

from rest_framework import generics, filters
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.permissions import DjangoModelPermissions

from . models import Newinquiry
from . serializers import NewinquirySerializer


class NewinquiryList(generics.ListCreateAPIView):

    queryset = Newinquiry.objects.all()
    serializer_class = NewinquirySerializer

    permission_classes = [DjangoModelPermissions, ]

    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['dateofinquiry']

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return Newinquiry.objects.all()
        elif user.groups.name == 'Manager':
            return Newinquiry.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return Newinquiry.objects.filter(created_by=user)


class NewinquiryDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Newinquiry.objects.all()
    serializer_class = NewinquirySerializer

    permission_classes = [DjangoModelPermissions, ]

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return Newinquiry.objects.all()
        elif user.groups.name == 'Manager':
            return Newinquiry.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return Newinquiry.objects.filter(created_by=user)


@api_view(['GET'])
def inquiry_count_datewise(request):

    data = Newinquiry.objects.all().annotate(date=F('dateofinquiry')).values(
        'date').annotate(inquiry=Count('id'))

    user = request.user

    if user.groups.name == 'Manager':
        data = data.filter(
            Q(created_by=user) |
            Q(created_by__reports_to=user)
        )
    elif user.groups.name == 'BDE':
        data = data.filter(created_by=user)

    return Response(data)
