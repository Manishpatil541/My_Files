from django.urls import path
from apps.inquiry import views

urlpatterns = [
    path('', views.NewinquiryList.as_view(), name='inquiry_list'),
    path('<int:pk>/', views.NewinquiryDetail.as_view(), name='inquiry_detail'),
    path('datewise-count', views.inquiry_count_datewise)
]
