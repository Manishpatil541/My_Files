from rest_framework import serializers
from . models import Newinquiry


class NewinquirySerializer(serializers.ModelSerializer):

    country_name = serializers.ReadOnlyField(source='region.name')
    country_alpha3 = serializers.ReadOnlyField(source='country.alpha3')

    created_by_email = serializers.ReadOnlyField(source='created_by.email')

    class Meta:
        model = Newinquiry
        fields = ['id', 'irr_no', 'ref_no', 'customername', 'types', 'owner', 'contactperson', 'contactnumber', 'country_name', 'country_alpha3',
                  'customeremail_id', 'region', 'customeraddress', 'dateofinquiry', 'targetdate', 'briefinquirydescription', 'created_by',
                  'created_by_email']
