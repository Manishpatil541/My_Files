from django.db import models
from django.utils.translation import gettext as _
from django.utils import timezone
from django_countries.fields import CountryField
from django.contrib.auth import get_user_model
from django.db.models import Q

# Create your models here.

User = get_user_model()


class InquiryType(models.TextChoices):

    QUOTE = 'Quote'
    RFQ = 'Rfq'
    INQUIRY = 'Inquiry'
    RFP = 'Rfp'


class Newinquiry(models.Model):
    irr_no = models.CharField(_("IRR_No"), max_length=100)
    ref_no = models.CharField(_("Reference No"), max_length=100, default="", blank=True)
    types = models.CharField(_("Type"),
                             max_length=25, choices=InquiryType.choices)
    owner = models.CharField(_("Owner"), max_length=100)
    customername = models.CharField(_("Customer Name"), max_length=100)
    contactperson = models.CharField(_("Contact Person"), max_length=100)
    contactnumber = models.CharField(_("Contact Number"), max_length=25)
    customeremail_id = models.EmailField(_("Customer Email Id"))
    region = CountryField(_("Region"))
    customeraddress = models.TextField(_("Customer Address"), max_length=100)
    dateofinquiry = models.DateField(
        _("Date of Inquiry"), auto_now=False, auto_now_add=False)
    targetdate = models.DateField(
        _("Target Date"), auto_now=False, auto_now_add=False)
    briefinquirydescription = models.TextField(
        _("Brief Inquiry Description"), max_length=100)
    created_by = models.ForeignKey(
        User, null=True, blank=True, related_name="inquiry_created", on_delete=models.RESTRICT)
    assigned_to = models.ForeignKey(User, null=True, blank=True,
                                    on_delete=models.RESTRICT, related_name="inquiry_assigned_to")
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

    # class Meta:
    #     unique_together = ('pref', 'nums', 'static_id')

    # @property
    # def static_key(self):
    #     return self.pref + str(self.static_id).zfill(self.nums)

    class Meta:
        verbose_name = _("Newinquiry")
        verbose_name_plural = _("Newinquirys")

    def __str__(self):
        return self.owner

    @classmethod
    def search(cls, user, term ):

        queryset = None

        # filter based on user
        if user.groups.name in ['CEO', 'Admin']:
            queryset = Newinquiry.objects.all()
        elif user.groups.name == 'Manager':
            queryset = Newinquiry.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user) 
            )
        else:
            queryset = Newinquiry.objects.filter(created_by=user)

        inquiry_list = ["irr_no","ref_no","types","owner","customername","contactperson",
        "contactnumber","customeremail_id","region","customeraddress","dateofinquiry",
        "targetdate","briefinquirydescription","created_on","modified_on"]

        query = Q()
        for inquiry in inquiry_list:
            inquiry += '__icontains'
            query.add(Q(**{inquiry: term}), Q.OR)

        result = queryset.filter(query)
        return result

        
    


