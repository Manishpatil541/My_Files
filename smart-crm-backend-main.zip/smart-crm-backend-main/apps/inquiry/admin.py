from django.contrib import admin
from . models import Newinquiry

# Register your models here.

class NewinquiryAdmin(admin.ModelAdmin):
    list_display = ['irr_no','customername','types','owner','contactperson','contactnumber',
    'customeremail_id','region','customeraddress','dateofinquiry','targetdate','briefinquirydescription']

admin.site.register(Newinquiry,NewinquiryAdmin)