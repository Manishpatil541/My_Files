from djoser.serializers import UserCreateSerializer
from django.contrib.auth import get_user_model
from rest_framework import serializers
User = get_user_model()


class UserCreateSerializer(UserCreateSerializer):
    class Meta(UserCreateSerializer.Meta):
        model = User
        fields = ('id', 'email', 'first_name', 'last_name', 'password')


class UserProfileSerializer(serializers.ModelSerializer):

    group = serializers.ReadOnlyField(source='groups.name')
    reports_to_email = serializers.ReadOnlyField(source='reports_to.email')

    class Meta:
        model = User
        fields = ('id', 'username', 'avatar', 'role', 'language', 'accesskey', 'is_admin', 'primarygroup', 'reports_to',
                  'first_name', 'last_name', 'title', 'department', 'email',
                  'secondary_email_id', 'other_email_id', 'home_phone', 'office_phone', 'mobile_phone',
                  'secondary_phone', 'fax', 'last_updated',
                  'country', 'state', 'region', 'street', 'postal_code', 'group',
                  'reports_to_email')
