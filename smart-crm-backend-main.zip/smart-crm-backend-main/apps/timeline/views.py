from django.db.models import Q

from rest_framework.response import Response
from rest_framework.decorators import api_view
import datetime

from .models import Timeline
from .serializers import TimelineSerializer


@api_view(['GET'])
def data_range(request):
    new_format = "%a %b %d %Y %H:%M:%S"  # format of prime react calendar

    start_range, _ = request.GET.get('start_date').split(" GMT")
    start_range = datetime.datetime.strptime(
        start_range, new_format)
    end_range, _ = request.GET.get('end_date').split(" GMT")
    end_range = datetime.datetime.strptime(
        end_range, new_format) + datetime.timedelta(days=1)

    timeline = Timeline.objects.filter(
        date_time__range=[start_range, end_range])

    # filter based on user
    user = request.user

    if user.groups.name in ['CEO', 'Admin']:
        pass
    elif user.groups.name == 'Manager':
        timeline = timeline.filter(
            Q(user=user) |
            Q(user__reports_to=user)
        )
    else:
        timeline = timeline.filter(user=user)

    serialized_timeline = TimelineSerializer(
        timeline, many=True, partial=True)

    data = serialized_timeline.data

    return Response(data)
