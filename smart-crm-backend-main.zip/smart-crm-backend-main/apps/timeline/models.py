from django.db import models
from django.contrib.auth import get_user_model


User = get_user_model()


class ActivityType(models.TextChoices):

    CUSTOMER = 'Customer'
    EVENT = 'Event'
    INQUIRY = 'Inquiry'
    PO = 'PO'


class Timeline(models.Model):
    activity_id = models.IntegerField(null=True)
    activity = models.CharField(max_length=150)
    types = models.CharField(
        max_length=25, choices=ActivityType.choices, default=ActivityType.CUSTOMER)
    date_time = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    class Meta:
        ordering = ['-date_time']

    def __str__(self):
        return self.activity
