from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Timeline
from apps.events.models import Event
from apps.inquiry.models import Newinquiry
from apps.customer.models import Customer
from apps.customer_po.models import PoDetail
from .models import ActivityType


@receiver(post_save, sender='events.Event')
def event_creation(sender, instance, created, **kwargs):

    if created:
        activity = f'Event Created For Customer {instance.customer_name}'
        a = Timeline.objects.create(
            activity=activity, activity_id=instance.id, types=ActivityType.EVENT, user=instance.created_by)

        a.save()

    elif not created:
        activity = f'Event Updated For Customer {instance.customer_name}'
        a = Timeline.objects.create(
            activity=activity, activity_id=instance.id, types=ActivityType.EVENT, user=instance.created_by)


@receiver(post_save, sender='inquiry.Newinquiry')
def inquiry_creation(sender, instance, created, **kwargs):

    if created:
        activity = f'Inquiry Created For Customer {instance.customername}'
        a = Timeline.objects.create(activity=activity, activity_id=instance.id,
                                    types=ActivityType.INQUIRY, user=instance.created_by)
        a.save()

    elif not created:
        activity = f'Inquiry Updated For Customer {instance.customername}'
        a = Timeline.objects.create(activity=activity, activity_id=instance.id,
                                    types=ActivityType.INQUIRY, user=instance.created_by)


@receiver(post_save, sender='customer.Customer')
def customer_creation(sender, instance, created, **kwargs):

    if created:
        activity = f'New Customer {instance.customer} Added'
        a = Timeline.objects.create(activity=activity, activity_id=instance.id,
                                    types=ActivityType.CUSTOMER, user=instance.created_by)
        a.save()

    elif not created:
        activity = f'Customer {instance.customer} have been Updated'
        a = Timeline.objects.create(activity=activity, activity_id=instance.id,
                                    types=ActivityType.CUSTOMER, user=instance.created_by)


@receiver(post_save, sender='customer_po.PoDetail')
def po_creation(sender, instance, created, **kwargs):

    if created:
        activity = f'New Po have been generated for Customer {instance.customer_name}'
        a = Timeline.objects.create(
            activity=activity, activity_id=instance.id, types=ActivityType.PO, user=instance.created_by)
        a.save()

    elif not created:
        activity = f'{instance.customer_name} Customer Po  have been Updated'
        a = Timeline.objects.create(
            activity=activity, activity_id=instance.id, types=ActivityType.PO, user=instance.created_by)
