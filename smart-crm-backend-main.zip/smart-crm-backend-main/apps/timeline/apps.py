from django.apps import AppConfig


class TimelineConfig(AppConfig):
    name = 'apps.timeline'

    def ready(self):
        # import signals
        from apps.timeline import signals
