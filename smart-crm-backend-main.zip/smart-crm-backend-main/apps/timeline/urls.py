from django.urls import path

from .views import data_range

urlpatterns = [
    path('', data_range),
]
