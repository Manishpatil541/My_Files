from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
# Create your views here.
from apps.events.models import Event
from apps.events.serializers import EventSerializer

from apps.inquiry.models import Newinquiry
from apps.inquiry.serializers import NewinquirySerializer

from apps.customer_po.models import PoDetail
from apps.customer_po.serializers import POSerializer

from apps.customer.models import Customer
from apps.customer.serializers.customer import CustomerSerializer

from django.db.models import Q
from django.contrib.auth.models import AnonymousUser

class SearchView(APIView):
    
    def get(self, request):
        user = self.request.user

        if type(user) == AnonymousUser:
            return Response("Please login")

        data = {}
        q = request.GET.get('q','')

        if not q:
            return Response('Please provide search term')

        # list of models - (Model, Serializer) to be searched
        # model must have defined .search(user, term) -- classmethod
        models = [
            (Customer, CustomerSerializer), 
            (Event, EventSerializer),
            (Newinquiry,NewinquirySerializer),
            (PoDetail,POSerializer)
            ]

        for (model, serializer) in models:
        
            data[model.__name__.lower()] = serializer(model.search(user=user, term=q), many=True).data

        
        return Response(data)

        
    