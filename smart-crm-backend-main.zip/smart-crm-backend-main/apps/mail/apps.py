from django.apps import AppConfig


class MailConfig(AppConfig):
    name = 'apps.mail'

    def ready(self):
        # import signals
        from apps.mail import signals
