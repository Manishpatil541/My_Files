from django.core.mail import send_mail, EmailMessage
from django.utils import timezone
from django.template.loader import get_template

import datetime
from calendar import monthrange

from apps.customer.models import CustomerNote
from apps.events.models import Event, EventNote
from apps.inquiry.models import Newinquiry
from apps.customer_po.models import PoDetail
from apps.customer.models import Customer
from apps.login.models import User

from utils import get_host_email

host_email = get_host_email()


def notify_upcoming_event():
    '''Notify upcoming events before three days'''

    today = timezone.now()

    three_days_after = today + datetime.timedelta(days=3)
    four_days_after = today + datetime.timedelta(days=4)

    upcoming_events = Event.objects.filter(
        start_date__range=[three_days_after.date(), four_days_after.date()])

    for event in upcoming_events:
        user_emails = event.customer_name.get_user_emails()

        send_mail(
            'Event Reminder',
            f'You have a event with {event.customer_name} on {event.start_date} at {event.start_time}',
            host_email,
            user_emails,
            fail_silently=True
        )


def notify_important_leads():
    '''Notifies for stagep4, stagep5 customers which have no progress
    for about 15 days'''

    today = timezone.now()
    fifteen_days_back = today - datetime.timedelta(days=0)
    customers = Customer.objects.filter(
        outcome=Customer.OutcomeTypes.PROSPECT, modified_on__lte=fifteen_days_back, stagep3__isnull=False)

    for customer in customers:
        user_mails = customer.get_user_emails()

        subject = 'Customer Reminder'
        message = f'Customer {customer.customer} with {customer.current_stage} have not been checked for the past {(today - customer.modified_on).days} days'

        email = EmailMessage(
            subject,
            message,
            host_email,
            user_mails,
            cc=User.get_ceo_emails() or [host_email]
        )

        email.send(fail_silently=True)


def weekly_report_for_ceo():
    """ sends mail for ceo  weekly basis which includes with number of customer added,
    stages completed, events, inquires and customer po
    """
    # TODO: mail should be sending on monday mrng for the current week monday to sunday.

    today = timezone.now()
    week_start_date_tz = today + datetime.timedelta(-today.weekday(), weeks=-1)
    week_start_date = datetime.datetime.strftime(
        week_start_date_tz, "%d-%m-%Y")
    week_end_date_tz = today + datetime.timedelta(6-today.weekday(), weeks=-1)
    week_end_date = datetime.datetime.strftime(
        week_end_date_tz, "%d-%m-%Y")

    customers = Customer.objects.filter(
        outcome=Customer.OutcomeTypes.PROSPECT, created_on__lte=week_end_date_tz, created_on__gte=week_start_date_tz)
    converted_customer = Customer.objects.filter(
        outcome_date__lte=week_end_date_tz, outcome_date__gte=week_start_date_tz)
    events = Event.objects.filter(
        created_time__lte=week_end_date_tz, created_time__gte=week_start_date_tz)
    inquirys = Newinquiry.objects.filter(
        created_on__lte=week_end_date_tz, created_on__gte=week_start_date_tz)
    customerpos = PoDetail.objects.filter(
        created_on__lte=week_end_date_tz, created_on__gte=week_start_date_tz)

    message = get_template('weekly_report.html')

    subject = f"Weekly Report for {week_start_date} to {week_end_date}"

    data = ({
        "start_date": week_start_date,
        "end_date": week_end_date,
        "customers": len(customers),
        "converted_customer": len(converted_customer),
        "events": len(events),
        "inquiry": len(inquirys),
        "customerpo": len(customerpos)
    })

    html_message = message.render(data)

    email = EmailMessage(
        subject,
        html_message,
        host_email,
        User.get_ceo_emails() or [host_email],
    )

    email.send(fail_silently=True)


def monthly_report_for_ceo():
    """sends mail for ceo Monthly basis which includes summary of number of customer added,
    stages completed, events, inquires and customer po"""
    today = timezone.now()
    r_month = today.replace(month=today.month-1).strftime("%B")

    month_start_date = today.replace(day=1, month=today.month-1)
    month_end_date = today.replace(day=monthrange(
        today.year, today.month-1)[1], month=today.month-1)

    customers = Customer.objects.filter(
        outcome=Customer.OutcomeTypes.PROSPECT, created_on__lte=month_end_date, created_on__gte=month_start_date)
    converted_customer = Customer.objects.filter(
        outcome_date__lte=month_end_date, outcome_date__gte=month_start_date)
    events = Event.objects.filter(
        created_time__lte=month_end_date, created_time__gte=month_start_date)
    inquirys = Newinquiry.objects.filter(
        created_on__lte=month_end_date, created_on__gte=month_start_date)
    customerpos = PoDetail.objects.filter(
        created_on__lte=month_end_date, created_on__gte=month_start_date)

    message = get_template('monthly_report.html')

    subject = f"{r_month} month report"

    data = ({
        "month": r_month,
        "customers": len(customers),
        "converted_customer": len(converted_customer),
        "events": len(events),
        "inquiry": len(inquirys),
        "customerpo": len(customerpos)
    })

    html_message = message.render(data)

    email = EmailMessage(
        subject,
        html_message,
        host_email,
        User.get_ceo_emails() or [host_email],
    )

    email.send(fail_silently=True)


def remind_customer_notes():

    today = timezone.now()
    notes = CustomerNote.objects.filter(remind_on__date=today, reminded=False)

    for note in notes:

        user_emails = note.customer.get_user_emails()

        send_mail(
            'Notes Reminder',
            f'You have a reminder "{note.message}" {note.remind_on.strftime("%d %B, %Y %Z")} || customer: {note.customer}',
            host_email,
            user_emails,
            fail_silently=True
        )

        note.reminded = True
        note.save()


def remind_event_notes():

    today = timezone.now()
    notes = EventNote.objects.filter(remind_on__date=today, reminded=False)

    for note in notes:

        user_email = note.user.email

        send_mail(
            'Event Notes Reminder',
            f'You have a reminder "{note.message}" {note.remind_on.strftime("%d %B, %Y %Z")}',
            host_email,
            [user_email, ],
            fail_silently=True
        )

        note.reminded = True
        note.save()
