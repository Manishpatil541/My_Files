from django.conf import settings
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from django.db.models.signals import post_save
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template

from apps.customer.signals import customer_approval_request, outcome_change_signal
from apps.customer.models import Customer

from utils import get_host_email


host_email = get_host_email()
User = get_user_model()


@receiver(customer_approval_request)
def on_customer_approval_request(sender, new_customer, existing_customers, **kwargs):

    html_template = get_template('prospect_approval.html')
    data = {'new_customer': new_customer,
            'existing_customers': existing_customers}
    html_message = html_template.render(data)

    message = f'Customer with existing data was added - please visit SmartCRM'

    # send mail
    mail = EmailMultiAlternatives(
        f'Customer approval - {new_customer.customer}',
        message,
        host_email,
        User.get_ceo_emails() or [host_email],
    )
    mail.attach_alternative(html_message, "text/html")
    mail.send(fail_silently=True)


@receiver(post_save, sender='customer_po.PoDetail')
def on_customer_po_generation(sender, instance, **kwargs):

    html_template = get_template('po_generation.html')
    data = {'po_detail': instance}
    html_message = html_template.render(data)

    message = f'Customer PO has been generated for {instance.customer_name.customer}'

    # send mail
    mail = EmailMultiAlternatives(
        f'Customer Po Generation {instance.customer_name.customer}',
        message,
        host_email,
        User.get_ceo_emails() or [host_email],
    )
    mail.attach_alternative(html_message, "text/html")
    mail.send(fail_silently=True)


@receiver(outcome_change_signal)
def on_outcome_change(instance, *args, **kwargs):

    message = f'''
Outcome have been changes for {instance.customer} to {instance.outcome}

Current Customer Count
Confirmed: {Customer.objects.filter(outcome=Customer.OutcomeTypes.WON).count()}
Prospect: {Customer.objects.filter(outcome=Customer.OutcomeTypes.PROSPECT).count()}
Loss: {Customer.objects.filter(outcome=Customer.OutcomeTypes.LOSS).count()}
Drop: {Customer.objects.filter(outcome=Customer.OutcomeTypes.DROP).count()}
'''

    email = EmailMultiAlternatives(
        f'Outcome changes for {instance.customer}',
        message,
        host_email,
        User.get_ceo_emails() or [host_email],
    )
    email.send(fail_silently=True)
