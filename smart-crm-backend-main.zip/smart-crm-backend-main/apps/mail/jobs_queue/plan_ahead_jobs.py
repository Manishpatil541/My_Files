from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template

import datetime

from apps.customer.models import PlanAhead
from apps.login.models import User

from utils import get_host_email

host_email = get_host_email()


def remind_plan_ahead():
    """sends mail for bde alone every monday iff he has any plans for the current week"""

    date = datetime.date.today()  # todays date

    # getting this weeks start date i.e monday
    start_week = date - datetime.timedelta(date.weekday())

    # getting this weeks end date i.e saturday
    end_week = start_week + datetime.timedelta(6)

    # getting all the users
    users = User.objects.all()

    # filtering plan aheads only between this week monday to saturday for each user
    for user in users:
        plan_ahead = PlanAhead.objects.filter(created_by=user,
                                              expiry_week__range=[start_week, end_week])

    # iff plan ahead is there
        if(plan_ahead):

            data = {
                "start_week": start_week,
                "end_week": end_week,
                "plan_ahead": plan_ahead
            }

            subject = f"Plan for Potential Customers for the Week {start_week} - {end_week}"
            message = f"Please visit the Smart CRM for more info"

            html_message = get_template("plan_ahead.html").render(data)

            mail = EmailMultiAlternatives(
                subject,
                message,
                'crm@smartenovations.com',
                [user.email, ],
            )
            mail.attach_alternative(html_message, "text/html")
            mail.send(fail_silently=True)


def completed_plan_aheads():
    """Sends the status mail for bde on every monday for completing and postponing the plans for last week"""

    date = datetime.date.today()  # getting the tdays date

    # getting the start weeks date
    start_week = date - datetime.timedelta(date.weekday())

    # getting the last weeks start date
    start_week = start_week - datetime.timedelta(7)

    # getting the last weeks end date i.e saturday
    end_week = start_week + datetime.timedelta(6)

    # getting all the users
    users = User.objects.all()

    for user in users:

        # plan aheads for the filtered dates
        plan_ahead = PlanAhead.objects.filter(created_by=user,
                                              created_on__range=[start_week, end_week])

        # completed plan aheads for the filtered dates
        com_plan_ahead = PlanAhead.objects.filter(created_by=user,
                                                  completed=True, modified_on__range=[start_week, end_week])

        # executes iff plan ahead is not empty
        if(plan_ahead):
            postponed = 0
            postponed_plan = []
            for plan in plan_ahead:
                modified_date = plan.modified_on.date()

                # checking for the last log is next week and modified date is between next week monday to saturday
                if (plan.plan_ahead_types["log"][-1]["value"] == "Next Week" and modified_date >= start_week and modified_date <= end_week):
                    postponed += 1
                    postponed_plan.append(plan)

            data = {
                "start_week": start_week,
                "end_week": end_week,
                "plan_ahead": plan_ahead,
                "len_plan": len(plan_ahead),
                "com_plan_ahead": com_plan_ahead,
                "len_com_plan": len(com_plan_ahead),
                "postponed_plan": postponed_plan,
                "len_postponed_plan": len(postponed_plan),
                "not_progressed_plans": len(plan_ahead) - (len(com_plan_ahead) + len(postponed_plan)),
            }

            subject = f"Status of the plans for the Week {start_week} - {end_week}"
            message = f"Please visit the Smart CRM for more info"

            html_message = get_template("weekly_com_post.html").render(data)

            mail = EmailMultiAlternatives(
                subject,
                message,
                'crm@smartenovations.com',
                [user.email, ],
            )
            mail.attach_alternative(html_message, "text/html")
            mail.send(fail_silently=True)
