from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.db.models import F

from apps.customer.models import Customer, CURRENT_STAGE
from apps.login.models import User

from utils import get_host_email

host_email = get_host_email()


def stage_p4_and_p5_reminder_for_bde() -> None:
    """sends mail on every monday for stage p4 and stage p5 to all the users in the db"""

    filtered_customers = Customer.objects.filter(current_stage__in=[
        CURRENT_STAGE.Stage_P4, CURRENT_STAGE.Stage_P5], outcome=Customer.OutcomeTypes.PROSPECT)

    users = filtered_customers.values(user_id=F("created_by")).distinct()
    users_id = [u['user_id'] for u in users]
    users = User.objects.filter(id__in=users_id)

    for user in users:
        stage_4 = []
        stage_5 = []
        # getting 4th & 5th stage customers, sending mail for each user

        # filtering stage p4 for current user with outcome as prospect
        fourth_stage = filtered_customers.filter(created_by=user,
                                                 current_stage=CURRENT_STAGE.Stage_P4)
        for forth in fourth_stage:
            stage_4.append(forth)

        # filtering stage p5 for current user with outcome as prospect
        fifth_stage = filtered_customers.filter(created_by=user,
                                                current_stage=CURRENT_STAGE.Stage_P5)

        for fifth in fifth_stage:
            stage_5.append(fifth)

        data = {
            "stage_4": fourth_stage,
            "stage_5": fifth_stage
        }

        subject = f"Reminder for Stage P4 and Stage P5 prospects"

        if (fourth_stage or fifth_stage):
            html_message = get_template(
                "stagep4_p5_reminder.html").render(data)

            mail = EmailMultiAlternatives(
                subject,
                "Reminder for stage P4 and P5 prospects",
                host_email,
                [user.email, ],
            )
            mail.attach_alternative(html_message, "text/html")
            mail.send(fail_silently=True)


def stage_p4_and_p5_reminder_for_ceo() -> None:
    """sends mail on every monday for stage p4 and stage p5 to ceo in the db"""

    stage_4 = []
    stage_5 = []

    filtered_customers = Customer.objects.filter(current_stage__in=[
        CURRENT_STAGE.Stage_P4, CURRENT_STAGE.Stage_P5], outcome=Customer.OutcomeTypes.PROSPECT)

    users = filtered_customers.values(user_id=F("created_by")).distinct()
    users_id = [u['user_id'] for u in users]
    users = User.objects.filter(id__in=users_id)

    for user in users:
        # getting 4th & 5th stage customers, sending mail for each user

        fourth_stage = Customer.objects.filter(created_by=user,
                                               current_stage=CURRENT_STAGE.Stage_P4, outcome=Customer.OutcomeTypes.PROSPECT)
        for forth in fourth_stage:
            stage_4.append(forth)

        fifth_stage = Customer.objects.filter(created_by=user,
                                              current_stage=CURRENT_STAGE.Stage_P5, outcome=Customer.OutcomeTypes.PROSPECT)
        for fifth in fifth_stage:
            stage_5.append(fifth)

        subject = f"Reminder for Stage P4 and Stage P5 prospects"

    if (stage_4 or stage_5):
        data = {
            "ceo": True,
            "users": users,
            "stage_c4": stage_4,
            "stage_c5": stage_5,
        }

        html_message = get_template(
            "stagep4_p5_reminder.html").render(data)

        mail = EmailMultiAlternatives(
            subject,
            "Reminder for stage P4 and P5 prospects",
            host_email,
            User.get_ceo_emails(),
        )
        mail.attach_alternative(html_message, "text/html")
        mail.send(fail_silently=True)
