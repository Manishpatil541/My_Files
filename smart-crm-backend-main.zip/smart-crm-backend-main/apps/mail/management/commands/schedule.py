from django.core.management.base import BaseCommand
import schedule
import time

from apps.mail.jobs import (notify_upcoming_event, notify_important_leads,
                            weekly_report_for_ceo, monthly_report_for_ceo,
                            remind_customer_notes, remind_event_notes)
from apps.mail.jobs_queue import (remind_plan_ahead, completed_plan_aheads,
                                  stage_p4_and_p5_reminder_for_ceo, stage_p4_and_p5_reminder_for_bde)


class Command(BaseCommand):

    def handle(self, *args, **options):

        # event mail notification
        # change it to days in production

        # every day at 00:01 am
        schedule.every().day.at('00:01').do(notify_upcoming_event)
        schedule.every().day.at('00:01').do(notify_important_leads)

        schedule.every().day.at('00:01').do(remind_customer_notes)
        schedule.every().day.at('00:01').do(remind_event_notes)

        schedule.every().monday.at('00:01').do(weekly_report_for_ceo)
        schedule.every(30).days.at('00:01').do(monthly_report_for_ceo)

        schedule.every().monday.at('00:01').do(remind_plan_ahead)
        schedule.every().monday.at('00:01').do(completed_plan_aheads)
        schedule.every().monday.at('00:01').do(
            stage_p4_and_p5_reminder_for_bde)
        schedule.every().monday.at('00:01').do(
            stage_p4_and_p5_reminder_for_ceo)

        # dev
        # comment while in production
        # schedule.every(5).seconds.do(notify_upcoming_event)
        # schedule.every(5).seconds.do(notify_important_leads)

        # schedule.every(5).seconds.do(remind_customer_notes)
        # schedule.every(5).seconds.do(remind_event_notes)

        # schedule.every(5).seconds.do(weekly_report_for_ceo)
        # schedule.every(30).seconds.do(monthly_report_for_ceo)

        # schedule.every(5).seconds.do(remind_plan_ahead)
        # schedule.every(5).seconds.do(completed_plan_aheads)
        # schedule.every(5).seconds.do(
        #     stage_p4_and_p5_reminder_for_bde)
        # schedule.every(5).seconds.do(
        #     stage_p4_and_p5_reminder_for_ceo)

        while True:
            schedule.run_pending()
            time.sleep(1)
