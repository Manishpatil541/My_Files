from django.db import models


class Note(models.Model):
    """Notes model with ability to add reminder"""

    message = models.TextField()

    is_reminder = models.BooleanField(default=False)
    reminded = models.BooleanField(default=False)
    remind_on = models.DateTimeField(null=True, blank=True)

    user = models.ForeignKey(
        'login.User', on_delete=models.CASCADE, null=True, blank=True)

    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.message

    class Meta:
        abstract = True
