from rest_framework import serializers

from .models import LayoutSettings


class LayoutSerializer(serializers.ModelSerializer):

    class Meta:
        model = LayoutSettings
        fields = ['layout', 'widget_show',
                  'date_modified', 'layout_created_by']
