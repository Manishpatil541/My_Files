from django.db import models
from django.contrib.auth import get_user_model
from django.utils.translation import gettext as _

# instantiate User
User = get_user_model()

# Create your models here.


class LayoutSettings(models.Model):

    layout = models.JSONField()
    widget_show = models.JSONField()
    layout_created_by = models.OneToOneField(User,
                                             on_delete=models.CASCADE,
                                             related_name='layout_created_by', primary_key=True)
    date_modified = models.DateTimeField(auto_now_add=False, auto_now=True)

    def __str__(self):
        return self.layout_created_by.email + " | %s" % self.date_modified

    class meta:
        verbose_name = _("Layout Setting")
        verbose_name_plural = _("Layout Settings")
