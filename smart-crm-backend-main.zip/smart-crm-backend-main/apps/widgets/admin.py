from django.contrib import admin
from .models import LayoutSettings

# Register your models here.
admin.site.register(LayoutSettings)