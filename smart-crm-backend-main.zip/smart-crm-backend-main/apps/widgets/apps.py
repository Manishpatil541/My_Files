from django.apps import AppConfig


class WidgetsConfig(AppConfig):
    name = 'apps.widgets'

    def ready(self):
        # import signals
        from apps.widgets.signals import layout_create_signal
