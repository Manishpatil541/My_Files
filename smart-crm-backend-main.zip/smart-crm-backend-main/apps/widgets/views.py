from django.shortcuts import render
from rest_framework import generics
from rest_framework.decorators import api_view
from rest_framework.response import Response
from pathlib import Path
import json


from .models import LayoutSettings
from .serializers import LayoutSerializer

# Create your views here.

abs_path = Path(__file__).resolve().parent


class LayoutWidgetList(generics.ListCreateAPIView):

    queryset = LayoutSettings.objects.all()
    serializer_class = LayoutSerializer

    def perform_create(self, serializer):
        serializer.save(layout_created_by=self.request.user)

class LayoutWidgetDetail(generics.RetrieveUpdateDestroyAPIView):

    queryset = LayoutSettings.objects.all()
    serializer_class = LayoutSerializer


@api_view(['get'])
def reset_layout_data(request):
    with open(abs_path / 'initial_layout_data.json') as jsonData:
        json_data = json.load(jsonData)
    with open(abs_path / 'initial_show_data.json') as showJsonData:
        show_json_data = json.load(showJsonData)

    data = {
        "layout": json_data,
        "widget_show": show_json_data
    }

    return Response(data)
