from django.urls import path
from apps.widgets import views

urlpatterns = [
    path('', views.LayoutWidgetList.as_view(), name='layout_list'),
    path('<int:pk>', views.LayoutWidgetDetail.as_view(), name='layout_detail'),
    path('reset-layout-data', views.reset_layout_data, name='reset_layout_data')
]
