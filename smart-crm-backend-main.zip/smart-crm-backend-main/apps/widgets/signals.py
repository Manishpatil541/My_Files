from django.contrib.auth import get_user_model

from django.db.models.signals import post_save
from django.dispatch import receiver
import json
from pathlib import Path

from .models import LayoutSettings

# instantiate User
User = get_user_model()

abs_path = Path(__file__).resolve().parent


@receiver(post_save, sender=User, dispatch_uid="layout_create_signal")
def layout_create_signal(sender, instance, created, **kwargs):
    with open(abs_path / 'initial_layout_data.json') as jsonData:
        json_data = json.load(jsonData)
    with open(abs_path / 'initial_show_data.json') as showJsonData:
        show_json_data = json.load(showJsonData)

    if created:
        l_setting = LayoutSettings.objects.create(
            layout=json_data, widget_show=show_json_data, layout_created_by=instance)
        l_setting.save()

        print("Layout created")
