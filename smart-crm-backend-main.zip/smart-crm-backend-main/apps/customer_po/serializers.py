from rest_framework import serializers
from .models import PoDetail
from django_countries import countries
from django_countries.serializer_fields import CountryField

from ..customer.serializers.customer import CustomerSerializerField


class POSerializer(serializers.ModelSerializer):

    region = CountryField()
    region_name = serializers.ReadOnlyField(source='region.name')
    region_alpha3 = serializers.ReadOnlyField(source='region.alpha3')

    customer_name = CustomerSerializerField()
    customer = serializers.ReadOnlyField(source='customer_name.customer')

    created_by_email = serializers.ReadOnlyField(source='created_by.email')

    class Meta:
        model = PoDetail
        all_fields = [f.name for f in PoDetail._meta.fields]
        fields = all_fields + ['region_name', 'region_alpha3', 'customer', 'created_by_email']

    
