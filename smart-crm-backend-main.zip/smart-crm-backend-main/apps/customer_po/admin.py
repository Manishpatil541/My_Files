from django.contrib import admin
from .models import PoDetail

# Register your models here.


class poAdmin(admin.ModelAdmin):

    list_display = ('customer_name', 'region', 'report_to', 'designer_name', 'po_no',
                    'issue_date', 'quotation_no', 'quotation_date', 'expiry_date', 'currency',
                    'rate_per_unit', 'rate', 'no_of_units',
                    'place_of_delivery', 'ssi_no', 'payment_terms', 'created_by')
    fieldsets = (
        ('PoDetails', {'fields': ('customer_name', 'region', 'report_to', 'designer_name', 'po_no',
                                  'issue_date', 'quotation_no', 'quotation_date', 'expiry_date', 'currency',
                                  'rate_per_unit', 'rate', 'no_of_units', 'no_of_units_consumed', 'place_of_delivery', 'ssi_no',
                                  'payment_terms', 'po_confirm_date', 'created_by')}),
        ('Invoice', {'fields': ('invoice_to', 'invoice_contact_no',
                                'vendor_code', 'vendor_gstn', 'vendor_state', 'vendor_state_code')}),
        ('Consignee', {'fields': ('consignee', 'consignee_email',
                                  'consignee_gstn', 'consignee_state', 'consignee_state_code', 'service_description')}),
    )


admin.site.register(PoDetail, poAdmin)
