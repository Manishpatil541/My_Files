from django.apps import AppConfig


class CustomerPoConfig(AppConfig):
    name = 'customer_po'
