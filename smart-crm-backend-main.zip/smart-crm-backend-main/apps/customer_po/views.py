from django.db.models import Q
from django.shortcuts import render
from rest_framework import generics
from rest_framework.permissions import DjangoModelPermissions

from .models import PoDetail
from .serializers import POSerializer

# Create your views here.


class PoList(generics.ListCreateAPIView):
    """PO test list view"""

    queryset = PoDetail.objects.all()
    serializer_class = POSerializer
    ordering_fields = ['created_on', 'modified_on']
    permission_classes = [DjangoModelPermissions, ]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return PoDetail.objects.all()
        elif user.groups.name == 'Manager':
            return PoDetail.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return PoDetail.objects.filter(created_by=user)


class PoDetailSerializer(generics.RetrieveUpdateDestroyAPIView):
    """PO test Detail view"""

    queryset = PoDetail.objects.all()
    serializer_class = POSerializer
    ordering_fields = ['created_on', 'modified_on']
    permission_classes = [DjangoModelPermissions, ]

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return PoDetail.objects.all()
        elif user.groups.name == 'Manager':
            return PoDetail.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return PoDetail.objects.filter(created_by=user)
