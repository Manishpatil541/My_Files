from django.db import models
from django_countries.fields import CountryField
from django.utils.translation import gettext as _
from django.contrib.auth import get_user_model
from django.db.models import Q
from ..customer.models import Customer

User = get_user_model()


class CurrencyType(models.TextChoices):

    INR = "INR"
    USD = "USD"
    EURO = "EURO"


class RateType(models.TextChoices):

    PER_HOUR = "Per Hour"
    PER_DAY = "Per Day"
    PER_MONTH = "Per Month"
    FIXED = "Fixed"


class PoDetail(models.Model):

    # PO Details

    customer_name = models.ForeignKey(Customer, on_delete=models.RESTRICT)

    region = CountryField(_("Region"))

    report_to = models.CharField(_("Report To"), blank=False,
                                 max_length=100)
    designer_name = models.CharField(_("Designer Name"), blank=True,
                                     max_length=100)
    po_no = models.CharField(_("PO Number"), max_length=50, blank=True)

    issue_date = models.DateField(_("Issue Date"), null=True, blank=True)

    quotation_no = models.CharField(_("Quotation Number"), blank=True,
                                    max_length=50, null=True)
    quotation_date = models.DateField(
        _("Quotation Date"), null=True, blank=True)

    expiry_date = models.DateField(_("PO Expiry Date"), blank=False)

    currency = models.CharField(_("Currency"),
                                max_length=50, choices=CurrencyType.choices, blank=False)

    rate_per_unit = models.CharField(_("Rate (Per Unit)"), max_length=100,
                                     choices=RateType.choices, blank=False)

    rate = models.CharField(_("Rate"), max_length=50, blank=False, null=True)

    no_of_units = models.CharField(
        _("No of Units"), max_length=50, blank=False)

    no_of_units_consumed = models.CharField(
        _("No. of units Consumed"), max_length=50, blank=False)

    place_of_delivery = models.CharField(_("Place of Delivery"),
                                         max_length=100, blank=True)

    ssi_no = models.CharField(_("SSI Number"), max_length=50, blank=True)

    payment_terms = models.CharField(
        _("Payment Terms"), max_length=100, null=True, blank=True)

    po_confirm_date = models.DateField(
        _("PO Confirmation Date"), null=True, blank=True)

    created_by = models.ForeignKey(
        User, null=True, blank=True, related_name='po_created_by', on_delete=models.RESTRICT)
    assigned_to = models.ForeignKey(User, null=True, blank=True,
                                    on_delete=models.RESTRICT, related_name="po_assigned_to")
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)

    # Invoice

    invoice_to = models.CharField(_("Invoice To (Name & Address)"),
                                  max_length=750, blank=False)
    invoice_contact_no = models.CharField(_("Contact Number"),
                                          max_length=20, blank=False, null=False)
    vendor_code = models.CharField(_("Vendor code"),
                                   max_length=50, blank=False)
    vendor_gstn = models.CharField(_("GSTN/VAT Number"),
                                   max_length=15, blank=False)
    vendor_state = models.CharField(_("State"),
                                    max_length=50, blank=False)
    vendor_state_code = models.CharField(_("State code"),
                                         max_length=50, blank=False)

    # Consignee

    consignee = models.CharField(_("Consignee Name & Address"),
                                 max_length=750, blank=True)
    consignee_email = models.EmailField(_("Email Id"),
                                        max_length=275, blank=True)
    consignee_gstn = models.CharField(_("GSTN/VAT Number"),
                                      max_length=15, blank=True)
    consignee_state = models.CharField(_("State"),
                                       max_length=50, blank=True)
    consignee_state_code = models.CharField(_("State code"),
                                            max_length=50, blank=True)
    service_description = models.CharField(_("Service Description"),
                                           max_length=1000, blank=True)

    @classmethod
    def search(cls, user, term):

        queryset = None

        # filter based on user
        if user.groups.name in ['CEO', 'Admin']:
            queryset = PoDetail.objects.all()
        elif user.groups.name == 'Manager':
            queryset = PoDetail.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            queryset = PoDetail.objects.filter(created_by=user)

        po_list = ["customer_name__customer", "region", "report_to", "designer_name", "po_no", "issue_date", "quotation_no", "quotation_date",
                   "expiry_date", "currency", "rate_per_unit", "rate", "no_of_units", "no_of_units_consumed", "place_of_delivery", "ssi_no", "payment_terms",
                   "po_confirm_date", "created_on", "modified_on", "invoice_to", "invoice_contact_no", "vendor_code", "vendor_gstn", "vendor_state", "vendor_state_code",
                   "consignee", "consignee_email", "consignee_gstn", "consignee_state", "consignee_state_code", "service_description"]

        query = Q()
        for po in po_list:
            po += '__icontains'
            query.add(Q(**{po: term}), Q.OR)

        result = queryset.filter(query)
        return result
