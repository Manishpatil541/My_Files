from django.urls import path
from .import views


urlpatterns = [
    path('', views.PoList.as_view(), name="PO_list"), #for api-list
    path('<int:pk>/', views.PoDetailSerializer.as_view(),
         name="PO_details"), #for api-detail
]
