from django.urls import path
from apps.report import views

urlpatterns = [
    path('data-range/', views.data_within_date_range),
    path('data-graph/', views.data_for_graph),
]
