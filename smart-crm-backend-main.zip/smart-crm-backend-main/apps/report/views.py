from django.shortcuts import render
from django.db.models import F, Count
from rest_framework.response import Response
from rest_framework.decorators import api_view
import datetime

from apps.events.models import Event
from apps.events.serializers import EventSerializer

from apps.inquiry.models import Newinquiry
from apps.inquiry.serializers import NewinquirySerializer

from apps.customer_po.models import PoDetail
from apps.customer_po.serializers import POSerializer

from apps.customer.models import Customer, PlanAhead
from apps.customer.serializers import CustomerSerializer, PlanAheadSerializer


# Create your views here.


@api_view(['GET'])
def data_within_date_range(request):
    new_format = "%a %b %d %Y %H:%M:%S"  # format of prime react calendar

    start_range, _ = request.GET.get('start_date').split(" GMT")
    start_range = datetime.datetime.strptime(
        start_range, new_format)
    end_range, _ = request.GET.get('end_date').split(" GMT")
    end_range = datetime.datetime.strptime(
        end_range, new_format) + datetime.timedelta(days=1)
    user = request.GET.get('user')

    if user == "None":
        customer = Customer.objects.filter(outcome=Customer.OutcomeTypes.PROSPECT,
            created_on__range=[start_range, end_range])
        serialized_customer = CustomerSerializer(
            customer, many=True, partial=True)

        converted_customer = Customer.objects.filter(
            outcome=Customer.OutcomeTypes.WON, outcome_date__range=[start_range, end_range])
        serialized_converted_customer = CustomerSerializer(
            converted_customer, many=True, partial=True)

        event = Event.objects.filter(
            created_time__range=[start_range, end_range])
        serialized_event = EventSerializer(event, many=True, partial=True)

        inquiry = Newinquiry.objects.filter(
            created_on__range=[start_range, end_range])
        serialized_inquiry = NewinquirySerializer(
            inquiry, many=True, partial=True)

        customerpo = PoDetail.objects.filter(
            created_on__range=[start_range, end_range])
        serialized_customerpo = POSerializer(
            customerpo, many=True, partial=True)

        plan_ahead = PlanAhead.objects.filter(
            created_on__range=[start_range, end_range])
        serialized_plan_ahead = PlanAheadSerializer(
            plan_ahead, many=True, partial=True)

        data = {
            "customers": serialized_customer.data,
            "converted_customer": serialized_converted_customer.data,
            "events": serialized_event.data,
            "inquirys": serialized_inquiry.data,
            "customerpos": serialized_customerpo.data,
            "planahead": serialized_plan_ahead.data
        }
        return Response(data)

    customer = Customer.objects.filter(outcome=Customer.OutcomeTypes.PROSPECT,
        created_by=user, created_on__range=[start_range, end_range])
    serialized_customer = CustomerSerializer(
        customer, many=True, partial=True)

    converted_customer = Customer.objects.filter(
        outcome=Customer.OutcomeTypes.WON, created_by=user, outcome_date__range=[start_range, end_range])
    serialized_converted_customer = CustomerSerializer(
        converted_customer, many=True, partial=True)

    event = Event.objects.filter(
        created_by=user, created_time__range=[start_range, end_range])
    serialized_event = EventSerializer(event, many=True, partial=True)

    inquiry = Newinquiry.objects.filter(
        created_by=user, created_on__range=[start_range, end_range])
    serialized_inquiry = NewinquirySerializer(
        inquiry, many=True, partial=True)

    customerpo = PoDetail.objects.filter(
        created_by=user, created_on__range=[start_range, end_range])
    serialized_customerpo = POSerializer(
        customerpo, many=True, partial=True)

    plan_ahead = PlanAhead.objects.filter(
        created_by=user, created_on__range=[start_range, end_range])
    serialized_plan_ahead = PlanAheadSerializer(
        plan_ahead, many=True, partial=True)

    data = {
        "customers": serialized_customer.data,
        "converted_customer": serialized_converted_customer.data,
        "events": serialized_event.data,
        "inquirys": serialized_inquiry.data,
        "customerpos": serialized_customerpo.data,
        "planahead": serialized_plan_ahead.data
    }

    return Response(data)


@api_view(['GET'])
def data_for_graph(request):
    new_format = "%a %b %d %Y %H:%M:%S"  # format of prime react calendar

    start_range, _ = request.GET.get('start_date').split(" GMT")
    start_range = datetime.datetime.strptime(
        start_range, new_format)
    end_range, _ = request.GET.get('end_date').split(" GMT")
    end_range = datetime.datetime.strptime(
        end_range, new_format) + datetime.timedelta(days=1)
    user = request.GET.get('user')

    if user != "None":
        customer = Customer.objects.filter(created_by=user, outcome=Customer.OutcomeTypes.PROSPECT, created_on__range=[
            start_range, end_range]).values('created_on__date').annotate(customers=Count('id')).order_by('created_on__date')

        converted_customer = Customer.objects.filter(created_by=user, outcome=Customer.OutcomeTypes.WON, outcome_date__range=[start_range, end_range]).values(
            'outcome_date').annotate(customers=Count('id')).order_by('outcome_date')

        events = Event.objects.filter(created_by=user, created_time__range=[start_range, end_range]).values(
            'created_time__date').annotate(events=Count('id'))

        inquirys = Newinquiry.objects.filter(created_by=user, created_on__range=[start_range, end_range]).values(
            'created_on__date').annotate(inquirys=Count('id'))

        customerpos = PoDetail.objects.filter(created_by=user, created_on__range=[start_range, end_range]).values(
            'created_on__date').annotate(customerpos=Count('id'))

        planahead = PlanAhead.objects.filter(created_by=user, created_on__range=[start_range, end_range]).values(
            'created_on__date').annotate(planahead=Count('company_name'))

        data = {
            "customers": customer,
            "converted_customer": converted_customer,
            "events": events,
            "inquirys": inquirys,
            "customerpos": customerpos,
            "planahead": planahead
        }

        return Response(data)

    customer = Customer.objects.filter(outcome=Customer.OutcomeTypes.PROSPECT, created_on__range=[
                                       start_range, end_range]).values('created_on__date').annotate(customers=Count('id')).order_by('created_on__date')
    converted_customer = Customer.objects.filter(outcome=Customer.OutcomeTypes.WON, outcome_date__range=[start_range, end_range]).values(
        'outcome_date').annotate(customers=Count('id')).order_by('outcome_date')
    events = Event.objects.filter(created_time__range=[start_range, end_range]).values(
        'created_time__date').annotate(events=Count('id'))
    inquirys = Newinquiry.objects.filter(created_on__range=[start_range, end_range]).values(
        'created_on__date').annotate(inquirys=Count('id'))
    customerpos = PoDetail.objects.filter(created_on__range=[start_range, end_range]).values(
        'created_on__date').annotate(customerpos=Count('id'))
    planahead = PlanAhead.objects.filter(created_on__range=[start_range, end_range]).values(
        'created_on__date').annotate(planahead=Count('company_name'))

    data = {
        "customers": customer,
        "converted_customer": converted_customer,
        "events": events,
        "inquirys": inquirys,
        "customerpos": customerpos,
        "planahead": planahead
    }

    return Response(data)
