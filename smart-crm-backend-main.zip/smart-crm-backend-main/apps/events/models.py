from django.db import models
from django.utils.translation import gettext as _
from django.contrib.auth import get_user_model
from datetime import datetime
from django.db.models import Q
# from django.db.models.functions import datetime

from apps.common.models import Note
from ..customer.models import customer

User = get_user_model()
# Create your models here.


class ActivityType(models.TextChoices):

    CALL = 'Call'
    MEETING = 'Meeting'
    MOBILE_CALL = 'Mobile call'
    ON_SITE_MEETING = 'On site meeting'
    ON_SERVICE = 'On service'
    GROUP_EVENT = 'Group event'


class StatusType(models.TextChoices):

    PLANNED = 'Planned'
    HELD = 'Held'
    NOT_HELD = 'Not held'
    CANCELLED = 'Cancelled'


class VisibilityType(models.TextChoices):

    PRIVATE = 'Private'
    PUBLIC = 'Public'


class PriorityType(models.TextChoices):

    LOW = 'Low'
    MEDIUM = 'Medium'
    HIGH = 'High'


class OrganizationType(models.TextChoices):

    ORGANIZATION = 'Organization'
    CAMPAIGNS = 'Campaigns'
    CASES = 'Cases'
    INTERNAL_TICKETS = 'Internal tickets'
    INVOICES = 'Invoices'
    LEADS = 'Leads'
    OPPORTUNITIES = 'Opportunities'
    PROJECTS = 'Projects'
    PURCHASE_ORDER = 'Purchase order'
    QUOTES = 'Quotes'
    SALES_ORDER = 'Sales order'
    SERVICE_CONTRACTS = 'Service contracts'
    SERVICES = 'Services'
    WORKORDER = 'Work order'


class Event(models.Model):

    customer_name = models.ForeignKey(
        customer.Customer, related_name="customers", on_delete=models.RESTRICT)
    subject = models.TextField()
    start_date = models.DateField(auto_now=False, auto_now_add=False)
    end_date = models.DateField(auto_now=False, auto_now_add=False)
    activity_type = models.CharField(
        max_length=50, choices=ActivityType.choices, default=ActivityType.CALL)
    status_type = models.CharField(
        max_length=50, choices=StatusType.choices, default=StatusType.PLANNED)
    priority_type = models.CharField(
        max_length=50, choices=PriorityType.choices, default=PriorityType.LOW)
    visibility_type = models.CharField(
        max_length=50, choices=VisibilityType.choices, default=VisibilityType.PRIVATE)
    organization_type = models.CharField(
        max_length=100, choices=OrganizationType.choices, default=OrganizationType.ORGANIZATION)
    created_by = models.ForeignKey(User, null=True, blank=True,
                                   on_delete=models.RESTRICT,
                                   related_name='event_created_by')
    assigned_to = models.ForeignKey(User, null=False, blank=False,
                                    on_delete=models.RESTRICT, related_name="event_assigned_to")
    location = models.CharField(max_length=100)
    contact_name = models.CharField(max_length=100)
    created_time = models.DateTimeField(auto_now=False, auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True, auto_now_add=False)
    start_time = models.TimeField(auto_now=False, auto_now_add=False)
    end_time = models.TimeField(auto_now=False, auto_now_add=False)

    class meta:
        verbose_name = _("Event")
        verbose_name_plural = _("Events")

    def __str__(self):
        return self.subject

    def has_expired(self):

        date = datetime.today()
        date = datetime.strptime(str(date), '%Y-%m-%d %H:%M:%S.%f')

        if self.start_date < date.date() and self.status_type == StatusType.PLANNED:
            return True
        else:
            return False

    @classmethod
    def search(cls, user, term ):

        queryset = None

        # filter based on user
        if user.groups.name in ['CEO', 'Admin']:
            queryset = Event.objects.all()
        elif user.groups.name == 'Manager':
            queryset = Event.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user) 
            )
        else:
            queryset = Event.objects.filter(created_by=user)

        event_list = ["customer_name__customer","subject","start_date","end_date","activity_type",
        "status_type","priority_type","visibility_type","organization_type","location",
        "contact_name","created_time","modified_time","start_time","end_time"]

        query = Q()
        for event in event_list:
            event += '__icontains'
            query.add(Q(**{event: term}), Q.OR)

        result = queryset.filter(query)
        return result


class EventNote(Note):

    pass
