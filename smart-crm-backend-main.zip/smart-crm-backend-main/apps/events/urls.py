from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.events import views

app_name = 'event'

router = DefaultRouter()
router.register(r'notes', views.EventNoteViewSet, basename="event-notes")

urlpatterns = [
    path('', views.EventList.as_view(), name='event_list'),
    path('', include(router.urls)),
    path('<int:pk>/', views.EventDetail.as_view(), name='event_detail'),
    path('datewise-count', views.event_count_datewise),
]
