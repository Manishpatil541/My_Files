from rest_framework import generics, response, filters
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import viewsets
from rest_framework.permissions import DjangoModelPermissions

from django.utils.encoding import force_text
from django.db.models import Count, F, Q
from django.db.models.fields import NOT_PROVIDED

from .models import Event, EventNote
from .serializers import EventSerializer, EventNoteSerializer


class EventList(generics.ListCreateAPIView):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [DjangoModelPermissions, ]

    ordering_fields = ['start_date', 'modified_time']
    filterset_fields = ['status_type', ]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def options(self, request, *args, **kwargs):

        meta = self.metadata_class()
        data = meta.determine_metadata(request, self)

        data['default'] = {field.name: force_text(
            ''
            if (getattr(field, 'default', None) == NOT_PROVIDED)
            else getattr(field, 'default', None),
            strings_only=True)
            for field in Event._meta.get_fields()}

        return response.Response(data)

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return Event.objects.all()
        elif user.groups.name == 'Manager':
            return Event.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return Event.objects.filter(Q(assigned_to=user) | Q(created_by=user))


class EventDetail(generics.RetrieveUpdateDestroyAPIView):

    queryset = Event.objects.all()
    serializer_class = EventSerializer

    permission_classes = [DjangoModelPermissions, ]

    def get_queryset(self):
        user = self.request.user

        if user.groups.name in ['CEO', 'Admin']:
            return Event.objects.all()
        elif user.groups.name == 'Manager':
            return Event.objects.filter(
                Q(created_by=user) |
                Q(created_by__reports_to=user)
            )
        else:
            return Event.objects.filter(Q(assigned_to=user) | Q(created_by=user))


@api_view(['GET'])
def event_count_datewise(request):

    data = Event.objects.all().annotate(date=F('start_date')).values(
        'date').annotate(events=Count('id')).order_by('date')

    user = request.user

    if user.groups.name == 'Manager':
        data = data.filter(
            Q(created_by=user) |
            Q(created_by__reports_to=user)
        )
    elif user.groups.name == 'BDE':
        data = data.filter(created_by=user)

    return Response(data)


class EventNoteViewSet(viewsets.ModelViewSet):

    serializer_class = EventNoteSerializer

    filterset_fields = ['is_reminder', ]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    def get_queryset(self):
        user = self.request.user

        return EventNote.objects.filter(user=user)
