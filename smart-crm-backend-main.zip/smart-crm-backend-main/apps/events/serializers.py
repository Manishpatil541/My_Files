from rest_framework import serializers
from django.contrib.auth import get_user_model

from .models import Event, EventNote
from ..customer.models import Customer
from ..customer.serializers.customer import CustomerSerializerField

User = get_user_model()


class EventSerializer(serializers.ModelSerializer):
    customer_name_value = serializers.SerializerMethodField(
        "get_customer_name")
    assigned_to = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(), many=False)
    customer_name = CustomerSerializerField()

    created_by_email = serializers.ReadOnlyField(source='created_by.email')

    # type of the model
    # to filter in frontend
    type = serializers.ReadOnlyField(default='event')

    class Meta:
        model = Event
        fields = ['id', 'customer_name', 'customer_name_value',
                  'start_date', 'end_date',
                  'activity_type', 'status_type', 'priority_type',
                  'visibility_type', 'organization_type',
                  'created_by', 'assigned_to',
                  'location', 'contact_name',
                  'created_time', 'modified_time', 'start_time', 'end_time',
                  'subject', 'has_expired', 'created_by_email', 'type']

    def get_customer_name(self, event):
        customer_name_value = event.customer_name.customer
        return customer_name_value


class EventNoteSerializer(serializers.ModelSerializer):

    user_email = serializers.ReadOnlyField(source='user.email')

    class Meta:
        model = EventNote
        fields = ['id', 'message', 'is_reminder', 'reminded',
                  'remind_on', 'user', 'created_on', 'user_email']
