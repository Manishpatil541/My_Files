from django.contrib import admin
from .models import Event, EventNote

# Register your models here.
admin.site.register(Event)
admin.site.register(EventNote)
