from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

from rest_framework.schemas import get_schema_view
from rest_framework.documentation import include_docs_urls


urlpatterns = [
    path('auth/', include('djoser.urls')),
    path('auth/', include('djoser.urls.jwt')),
    path('auth/', include('djoser.social.urls')),
    path('api/', include('apps.login.urls')),
    path('admin/', admin.site.urls),
    path('api/', include('apps.customer.urls')),
    path('api/events/', include('apps.events.urls')),
    path('api/inquiry/', include('apps.inquiry.urls')),
    path('api/customer_po/', include('apps.customer_po.urls')),
    path('api/widgets/', include('apps.widgets.urls')),
    path('api/notification/', include('apps.notification.urls')),
    path('api-auth/',include('rest_framework.urls')),
    path('api/report/', include('apps.report.urls')),
    path('api/timeline/', include('apps.timeline.urls')),
    path('api/search', include('apps.searchbar.urls')),
    path('docs/', include_docs_urls(title="CRM-API")),
    path('schema/', get_schema_view(
        title="CRM_API",
        description="API for all things _",
        version="1.0.0"
    ), name="openapi-schema"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns += staticfiles_urlpatterns()

