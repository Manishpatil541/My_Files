from ._base import *


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/3.1/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'g_gi-wo(-*7)*4u!tm6yg%btxej-ho)p2#6c-s7_a04q5(=9b2'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

ALLOWED_HOSTS = ['*']


# cors header
CORS_ORIGIN_ALLOW_ALL = True


# fronend domain
DOMAIN = '127.0.0.1:3000'
SITE_NAME = "Smart CRM"