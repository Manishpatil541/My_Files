"""
WSGI config for smart_crm project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.1/howto/deployment/wsgi/
"""
activate_this = 'Z:\\WORK_CODE\\INTERNAL\\SmartCRM\\smart-crm-backend\\env\\Scripts\\activate_this.py'
exec(open(activate_this).read(), {'__file__': activate_this})

import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'smart_crm.settings.dev'

import sys

sys.path.append('Z:\\WORK_CODE\\INTERNAL\\SmartCRM\\smart-crm-backend')


activate_this = 'E:\\Office\\CRM\\smart-crm-backend\\env\\Scripts\\activate_this.py'
exec(open(activate_this).read(), {'__file__': activate_this})

from django.core.wsgi import get_wsgi_application


application = get_wsgi_application()
