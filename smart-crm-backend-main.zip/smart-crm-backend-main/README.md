"# smart-crm-backend"

# To Clone the Project use this command https://github.com/smartenovations-datascience/smart-crm-backend.git

# Permission

- Django default permission group is used for permissions based role
- load default permission by `python manage.py loaddata groups.json`
- available default groups are Admin, CEO, Manager, BDE

# mod wsgi config

- run `mod_wsgi-express module-config`

# mail-schedule.py nssm

- use nssm to register the schedule command as a windows service
- modify python executable path in smart_crm_mail.bat
