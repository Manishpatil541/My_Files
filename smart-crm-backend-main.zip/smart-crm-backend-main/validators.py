from django.core.validators import RegexValidator


mobile_number_validator = RegexValidator(regex=r'^(?!0+$)(\+\d{1,3}[- ]?)?(?!0+$)\d{10}$',
                                         message='Enter a valid mobile number')