from django.utils.encoding import force_text
from rest_framework.metadata import SimpleMetadata
from rest_framework.relations import ManyRelatedField, RelatedField


# implementation from https://stackoverflow.com/a/50989115/12930482
class ForeignKeyMetaData(SimpleMetadata):

    def get_field_info(self, field):
        field_info = super(ForeignKeyMetaData, self).get_field_info(field)
        if isinstance(field, (RelatedField, ManyRelatedField)):
            field_info['type'] = 'choice'
            field_info['choices'] = [
                {
                    'value': choice_value,
                    'display_name': force_text(choice_name, strings_only=True)
                }
                for choice_value, choice_name in field.get_choices().items()
            ]
        return field_info
