import axios from "axios";

export const url =
  window.location.host === "localhost:3000"
    ? "http://127.0.0.1:8000/"
    : "http://122.166.191.134:8000/";

const defaultOptions = {
  baseURL: url,
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
};

const instance = axios.create(defaultOptions);

// instance.interceptors.request.use(function (config) {
//   const token = localStorage.getItem("access");
//   config.headers.Authorization = token ? `JWT ${token}` : "";
//   return config;
// });

export default instance;