import React from 'react'
import "primereact/resources/themes/lara-light-indigo/theme.css"; 
import "primereact/resources/primereact.min.css";                  
import "primeicons/primeicons.css";       
import Controller from './components/Controller'

export default function App() {
  return (
    <Controller/>
  )
}
