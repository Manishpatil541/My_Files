import axios from "../axiosInstance";

export default class ControllerService {
  getControllerList = () => {
    return axios.get(`api/controller`).then((res) => res.data);
  };

  getControllerDetails = (id) => {
    return axios.get(`api/controller/${id}`).then((res) => res.data);
  };
}



