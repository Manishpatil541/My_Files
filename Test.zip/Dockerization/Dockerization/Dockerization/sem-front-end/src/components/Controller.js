import React, { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Toast } from "primereact/toast";
import { Button } from "primereact/button";
import { FileUpload } from "primereact/fileupload";
import { Toolbar } from "primereact/toolbar";
import { InputText } from "primereact/inputtext";
import ControllerService from './service'
import axios from "axios";

// const controllerService = new ControllerService();

const ControllerList = () => {
  const [controller, setController] = useState(null);
  const [globalFilter, setGlobalFilter] = useState(null);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const toast = useRef(null);
  const dt = useRef(null);

  const getAllData = () => {
    axios
      .get("http://localhost:8000/api/controller")
      .then((response) => {
        console.log(response.data);
        setController(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getAllData();
  }, []);

  const leftToolbarTemplate = () => {
    return (
      <React.Fragment>
        <Button
          label="New"
          icon="pi pi-plus"
          className="p-button-success mr-2"
        />
        <Button label="Delete" icon="pi pi-trash" className="p-button-danger" />
      </React.Fragment>
    );
  };

  const rightToolbarTemplate = () => {
    return (
      <React.Fragment>
        <FileUpload
          mode="basic"
          name="demo[]"
          auto
          url="https://primefaces.org/primereact/showcase/upload.php"
          accept=".csv"
          chooseLabel="Import"
          className="mr-2 inline-block"
        />
        <Button label="Export" icon="pi pi-upload" className="p-button-help" />
      </React.Fragment>
    );
  };

  const header = (
    <div className="table-header" style={{textAlign: "center"}}>
      <h5 className="mx-0 my-1">Manage Controller Data</h5>
      <span className="p-input-icon-left">
        <i className="pi pi-search" />
        <InputText
          type="search"
          onInput={(e) => setGlobalFilter(e.target.value)}
          placeholder="Search..."
        />
      </span>
    </div>
  );

  return (
    <div className="datatable-crud-demo">
      <Toast ref={toast} />

      <div className="card">
          <h1 style={{textAlign: "center"}}>SEM</h1>
        {/* <Toolbar
          className="mb-4"
          left={leftToolbarTemplate}
          right={rightToolbarTemplate}
        ></Toolbar> */}

        <DataTable
          ref={dt}
          value={controller}
          selection={selectedProducts}
          onSelectionChange={(e) => setSelectedProducts(e.value)}
          dataKey="id"
          paginator
          rows={10}
          rowsPerPageOptions={[5, 10, 25]}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords} products"
          globalFilter={globalFilter}
          header={header}
          responsiveLayout="scroll"
        >
          <Column
            selectionMode="multiple"
            headerStyle={{ width: "3rem" }}
            exportable={false}
          ></Column>
          <Column
            field="high_temp_alarm_threshold"
            header="High Temp Alarm"
            sortable
          ></Column>
          <Column
            field="low_temp_alarm_threshold"
            header="Low Temp Alarm"
            sortable
            
          ></Column>
          <Column field="alarm_delay" header="A-Delay"></Column>
          <Column
            field="alarm_hysteresis"
            header="Alarm Hysteresis"
            sortable
            
          ></Column>
          <Column
            field="auxiliary_relay_action"
            header="auxilary Relay Action"
            sortable
            
          ></Column>
          <Column
            field="max_defrost_duration"
            header="Max Defrost Duration"
            sortable
           
          ></Column>
          <Column
            field="modified_on"
            header="Modified On"
            sortable
            
          ></Column>
          <Column
            field="created_on"
            header="Created On"
            sortable
            
          ></Column>
          <Column exportable={false} ></Column>
        </DataTable>
      </div>
    </div>
  );
};

export default ControllerList;
