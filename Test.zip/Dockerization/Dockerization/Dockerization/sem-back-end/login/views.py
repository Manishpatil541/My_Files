from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated

from .models import User
from .serializers import UserProfileSerializer


class ProfileViewSet(viewsets.ModelViewSet):

    parser_classes = (MultiPartParser, FormParser)

    permission_classes = [IsAuthenticated, ]

    queryset = User.objects.all()
    serializer_class = UserProfileSerializer
