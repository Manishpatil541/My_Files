
# Create your models here.
from django.db import models
from django.db.models import Q
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager, PermissionManager, Group
from django.utils import timezone



class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Users must have an email address')

        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)

        user.set_password(password)
        user.save()

        return user

    def create_superuser(self, email, password=None):
        """
        Creates and saves a superuser with the given email and password.
        """
        user = self.create_user(
            email,
            password=password,
        )
        admin,_ = Group.objects.get_or_create(name='admin')
        
        user.is_admin = True
        user.is_staff = True
        
        user.groups = admin

        user.save(using=self._db)
        return user


class RoleType(models.TextChoices):
    CEO = "CEO"
    Admin = "Admin"
    Manager = "Manager"
    Store_Manager = "Store Manager"
    Support_Manager = "Support Manager"
    Store_Superviser= "Store Superviser"
    Support_Representative = "Support Representative"
    IT_Consultant = "IT Consultant"


class User(AbstractBaseUser, PermissionsMixin):

    username = models.CharField(max_length=50, null=False, blank=False)

    avatar = models.ImageField(
        upload_to="avatar", default="default.png", null=False, blank=False)

    accesskey = models.CharField(max_length=25, null=True, blank=True)

    language = models.CharField(max_length=50, null=True, blank=True)

    role = models.CharField(
        max_length=50, choices=RoleType.choices, null=False, blank=False)

    reports_to = models.ForeignKey('User', default=None, null=True, blank=True,
                                   limit_choices_to=Q(groups__name='Manager') | Q(
                                       groups__name='CEO'),
                                   on_delete=models.SET_DEFAULT)

    first_name = models.CharField(max_length=255, null=False, blank=False)

    last_name = models.CharField(max_length=255, null=False, blank=False)

    email = models.EmailField(
        max_length=255, unique=True, null=False, blank=False)

    title = models.CharField(max_length=50, null=True, blank=True)

    department = models.CharField(max_length=50, null=True, blank=True)

    secondary_email_id = models.EmailField(null=True, blank=True)

    other_email_id = models.EmailField(null=True, blank=True)

    home_phone = models.CharField(max_length=50, null=True, blank=True)

    office_phone = models.CharField(max_length=50, null=True, blank=True)

    mobile_phone = models.CharField(max_length=25, null=True, blank=True)

    secondary_phone = models.CharField(max_length=50, null=True, blank=True)

    fax = models.CharField(max_length=50, null=True, blank=True)

    country = models.CharField(max_length=25, null=True, blank=True)

    state = models.CharField(max_length=25, null=True, blank=True)

    region = models.CharField(max_length=25, null=True, blank=True)

    street = models.CharField(max_length=50, null=True, blank=True)

    postal_code = models.CharField(max_length=25, null=True, blank=True)

    last_updated = models.DateTimeField(auto_now=True)

    groups = models.ForeignKey(
        Group, on_delete=models.RESTRICT, blank=True, null=True)

    is_active = models.BooleanField(default=True)

    is_staff = models.BooleanField(default=False)

    is_admin = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'

    def __str__(self):
        return self.email

    @property
    def is_superuser(self):
        return self.is_admin

    @classmethod
    def get_ceo_emails(cls) -> set:
        """Return all email of users in CEO group"""

        ceo_mails = []

        user: cls
        for user in cls.objects.filter(groups__name='CEO'):
            ceo_mails.append(user.email)

        return set(ceo_mails)
