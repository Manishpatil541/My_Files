from django import forms
from django.contrib import admin
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.core.exceptions import ValidationError

from . models import User


class UserCreationForm(forms.ModelForm):
    """A form for creating new users. Includes all the required
    fields, plus a repeated password."""
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput)
    password2 = forms.CharField(
        label='Password confirmation', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ('username', 'avatar', 'role', 'groups', 'language', 'accesskey', 'reports_to',
                  'first_name', 'last_name', 'title', 'department', 'email',
                  'secondary_email_id', 'other_email_id', 'office_phone', 'mobile_phone',
                  'secondary_phone', 'fax', 'is_staff',
                  'country', 'state', 'region', 'street', 'postal_code')

    def clean_password2(self):
        # Check that the two password entries match
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise ValidationError("Passwords don't match")
        return password2

    def save(self, commit=True):
        # Save the provided password in hashed format
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class UserChangeForm(forms.ModelForm):
    """A form for updating users. Includes all the fields on
    the user, but replaces the password field with admin's
    password hash display field.
    """
    password = ReadOnlyPasswordHashField()

    class Meta:
        model = User
        fields = ('username', 'avatar', 'role', 'groups', 'language', 'reports_to',
                  'first_name', 'last_name', 'title', 'department', 'email',
                  'secondary_email_id', 'other_email_id', 'office_phone', 'mobile_phone',
                  'secondary_phone', 'fax', 'password', 'is_active', 'is_admin', 'is_staff')

    def clean_password(self):
        # Regardless of what the user provides, return the initial value.
        # This is done here, rather than on the field, because the
        # field does not have access to the initial value
        return self.initial["password"]


class UserAdmin(BaseUserAdmin):
    # The forms to add and change user instances
    form = UserChangeForm
    add_form = UserCreationForm

    # The fields to be used in displaying the User model.
    # These override the definitions on the base UserAdmin
    # that reference specific fields on auth.User.
    list_display = ('email', 'is_admin')
    list_filter = ('is_admin',)
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('User info', {'fields': ('username', 'avatar', 'role', 'groups', 'language',
                                  'accesskey', 'reports_to')}),
        ('Employee info', {'fields': ('first_name', 'last_name', 'title', 'department',
                                      'secondary_email_id', 'other_email_id', 'home_phone', 'office_phone', 'mobile_phone',
                                      'secondary_phone', 'fax')}),
        ('User address', {'fields': ('country',
                                     'state', 'region', 'street', 'postal_code')}),
        ('Permissions', {'fields': ('is_active', 'is_admin',
                                    'is_staff', 'user_permissions')}),
    )
    # add_fieldsets is not a standard ModelAdmin attribute. UserAdmin
    # overrides get_fieldsets to use this attribute when creating a user.
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'avatar', 'role', 'groups', 'language', 'accesskey', 'reports_to',
                       'first_name', 'last_name', 'title', 'department', 'email', 'secondary_email_id',
                       'other_email_id', 'home_phone', 'office_phone', 'mobile_phone', 'secondary_phone', 'fax',
                       'country', 'state', 'region', 'street', 'postal_code',
                       'is_active', 'is_admin', 'password1', 'password2'),
        }),
    )
    readonly_fields = ('last_updated',)
    search_fields = ('email',)
    ordering = ('email',)
    filter_horizontal = ()


admin.site.register(User, UserAdmin)
