from django.urls import path, include
from rest_framework import routers

from .views import ControllerView


router = routers.DefaultRouter()
router.register(r'', ControllerView)

urlpatterns = [
    path('', include(router.urls)),
]
