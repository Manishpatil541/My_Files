from django.shortcuts import render

# Create your views here.
from .models import Controller
from .serializers import ControllerSerializer
from rest_framework import viewsets


class ControllerView(viewsets.ModelViewSet):
    queryset = Controller.objects.all()
    serializer_class = ControllerSerializer
