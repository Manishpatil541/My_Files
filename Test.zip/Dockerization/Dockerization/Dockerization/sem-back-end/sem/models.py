from faulthandler import disable
from django.db import models

# Create your models here.
class AlarmOptionType(models.TextChoices):

    Relative = "0"
    Absolute = "1"

class AuxiliaryRelayActionType(models.TextChoices):
    Cooling = "0"
    Heating = "1"

class AuxiliaryRelayProbeSelectionType(models.TextChoices):
    np ="0"
    P1 = "1"
    P2 = "2"
    P3 = "3"
    P4 = "4"

class AuxiliaryRelaySwitchedOffDuringDefrostType(models.TextChoices):
    The_Auxiliary_Relay_Operates_During_Defrost = "0"
    The_Auxiliary_Relay_Switched_Off_During_Defrost = "1"

class DefrostModeType(models.TextChoices):
    Electric = "0"
    Hot_Gas = "1"

class FanModeType(models.TextChoices):
    Runs_with_the_Compressor_and_Off_During_Defrost = "0"
    Continuous_Mode_and_Off_During_Defrost = "1"
    Runs_with_the_Compressor_During_Defrost = "2"
    Continuous_Mode_and_On_During_Defrost = "3"

class CompressorFanStatusType(models.TextChoices):
    Normal = "0" or "1"
    Copressor_Off = "2"

class ProbeSensorType(models.TextChoices):
    CTC = "0"
    NTC = "1"

class TemperatureMeasurementUnitType(models.TextChoices):
    Degree_Celcius = "0"
    Fahrenheit = "1"

class ControllerEnableType(models.TextChoices):
    disabled = "0"
    Enabled = "1"
    Not_Set = "2"

class ControllerStatusType(models.TextChoices):
    Refrigeration = "0"
    Defrost = "1"
    




class Controller(models.Model):
    alaram_option =  models.CharField(
        max_length=50, choices=AlarmOptionType.choices, null=False, blank=False)
    high_temp_alarm_threshold = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    low_temp_alarm_threshold = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    alarm_hysteresis = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    alarm_delay = models.IntegerField(blank=False)
    startup_alarm_delay = models.IntegerField(blank=False)
    discharge_air_sensor_failure = models.BooleanField(default=False)
    defrost_temp_sensor_failure = models.BooleanField(default=False)
    sensor_3_failure = models.BooleanField(default=False)
    condensing_unit_sensor_failure = models.BooleanField(default=False)
    high_temp_alarm = models.BooleanField(default=False)
    low_temp_alarm = models.BooleanField(default=False)
    external_alarm = models.BooleanField(default=False)
    pressure_switches_trip = models.BooleanField(default=False)
    door_open_status = models.BooleanField(default=False)
    condensing_unit_high_temp_alarm = models.BooleanField(default=False)
    condensing_unit_low_temp_alarm = models.BooleanField(default=False)

    auxiliary_relay_action = models.CharField(
        max_length=50, choices=AuxiliaryRelayActionType.choices, null=False, blank=False)

    auxiliary_relay_setpoint = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    auxiliary_relay_differential = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)

    auxiliary_relay_probe_selection = models.CharField(
        max_length=50, choices=AuxiliaryRelayProbeSelectionType.choices, null=False, blank=False)

    auxiliary_relay_switched_off_during_defrost = models.CharField(
        max_length=50, choices=AuxiliaryRelaySwitchedOffDuringDefrostType.choices, null=False, blank=False)

    defrost_mode = models.CharField(
        max_length=50, choices=DefrostModeType.choices, null=False, blank=False)

    defrost_termination_setpoint = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    defrost_interval = models.IntegerField(blank=False)
    max_defrost_duration = models.IntegerField(blank=False)
    defrost_delay = models.IntegerField(blank=False)
    drip_time = models.IntegerField(blank=False)
    defrost_delay_after_fast_freezing = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)

    fan_mode = models.CharField(
        max_length=50, choices=FanModeType.choices, null=False, blank=False)

    fan_delay_after_defrost = models.IntegerField(blank=False)
    fan_temp_hystersis = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    fan_stop_temp_setpoint = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    fan_ontime = models.IntegerField(blank=False)
    fan_offtime = models.IntegerField(blank=False)

    compressor_fan_status_when_door_open = models.CharField(
        max_length=50, choices=CompressorFanStatusType.choices, null=False, blank=False)
    
    probe_sensor_type = models.CharField(
        max_length=50, choices=ProbeSensorType.choices, null=False, blank=False)

    discharge_air_temp = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    defrost_temp_read = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    probe_3_value = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    probe_4_value = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    dl1_status = models.BooleanField(default=False)
    dl2_status = models.BooleanField(default=False)
    defrost_status = models.BooleanField(default=False)
    alarm_status = models.BooleanField(default=False)
    light_status = models.BooleanField(default=False)
    fan_status = models.BooleanField(default=False)
    aux_relay_status = models.BooleanField(default=False)
    compressor_status = models.BooleanField(default=False)
    buzzer_status = models.BooleanField(default=False)
    device_override = models.BooleanField(default=False)
    defrost_override = models.BooleanField(default=False)
    pulldown_override = models.BooleanField(default=False)
    keyboard_lock_unlock_status = models.BooleanField(default=False)
    mute_alarm_override = models.BooleanField(default=False)
    light_override = models.BooleanField(default=False)
    auxiliary_relay_override = models.BooleanField(default=False)
    differential_for_cut_in = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    minimum_setpoint_limit = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    maximum_setpoint_limit = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    compressor_startup_delay = models.IntegerField(default=False)
    minimum_compressor_off_time = models.IntegerField(default=False)
    pulldown_duration = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    pulldown_setpoint = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    failsafe_compressor_on_time = models.IntegerField(default=False)
    failsafe_compressor_off_time = models.IntegerField(default=False)

    temp_measurement_unit = models.CharField(
        max_length=50, choices=TemperatureMeasurementUnitType.choices, null=False, blank=False)

    active_setpoint = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    control_setpoint = models.DecimalField(max_digits=10, decimal_places=2, blank=False, null=True)
    modbus_slave_address = models.IntegerField(default=False)

    controller_enable = models.CharField(
        max_length=50, choices=ControllerEnableType.choices, null=False, blank=False)

    controller_status = models.CharField(
        max_length=50, choices=ControllerStatusType.choices, null=False, blank=False)

    neutral_zone_status = models.BooleanField(default=False)
    energy_saving_status = models.BooleanField(default=False)


    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)


    def __str__(self):
        return str(self.high_temp_alarm_threshold)
