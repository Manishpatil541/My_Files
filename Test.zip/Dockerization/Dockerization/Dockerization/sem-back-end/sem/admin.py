from django.contrib import admin
from .models import Controller

# Register your models here.
admin.site.register(Controller)