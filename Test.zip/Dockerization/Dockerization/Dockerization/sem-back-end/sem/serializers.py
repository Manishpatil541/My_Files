from rest_framework import serializers
from .models import Controller


class ControllerSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Controller
